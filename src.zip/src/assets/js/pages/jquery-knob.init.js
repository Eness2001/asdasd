/*
Template Name: Nazox -  Admin & Dashboard Template
Author: Themesdesign
Contact: themesdesign.in@gmail.com
File: Jquery knob init Js File
*/

$(function() {
    $(".knob").knob();
});