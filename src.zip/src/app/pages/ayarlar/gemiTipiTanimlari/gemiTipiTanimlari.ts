import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-gemiTipiTanimlari',
  templateUrl: './gemiTipiTanimlari.html'
})


export class gemiTipiTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalGemiTipiTanimlari') modalGemiTipiTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Gemi Tipi Tanımları")
    this.bs.change(['Ayarlar', 'Gemi TipiTanımları'])
    this.gemiTipiListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  gemiTipiTanimlariFormu = new FormGroup({
    islem           : new FormControl(''),
    method          : new FormControl(''),
    e_sira          : new FormControl(''),
    e_gemi_tipi_tr  : new FormControl(''),
    e_gemi_tipi_en  : new FormControl(''),
    ESKI_ID         : new FormControl('')
  })

  requestData
  responseData

  gemiTipiTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async gemiTipiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "gemiTipiTanimlari/gemiTipiListesi", {})
    if (this.responseData.DATA.length == 0) { this.gemiTipiTanimlari = null } else {this.gemiTipiTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async gemiTipiEkleButton() {
    this.gemiTipiTanimlariFormu.patchValue({
        islem           : 'gemiTipiTanimlari/gemiTipiEkle',
        method          : 'POST',
        e_sira          : '',
      e_gemi_tipi_tr  : '',
      e_gemi_tipi_en  : ''
    })
    this.modalHeader.title = "Gemi Tipi Ekleme Formu"
    this.modalAc(this.modalGemiTipiTanimlari, 'md')
  }

  async gemiTipiDuzenleButton(secilenKayit) {
    this.gemiTipiTanimlariFormu.patchValue({
      islem           : 'gemiTipiTanimlari/gemiTipiDuzenle',
      method          : 'PUT',
      e_sira          : secilenKayit.e_sira,
      e_gemi_tipi_tr  : secilenKayit.e_gemi_tipi_tr,
      e_gemi_tipi_en  : secilenKayit.e_gemi_tipi_en,
      ESKI_ID         : secilenKayit.e_id
    })
    this.modalHeader.title = "Gemi Tipi Düzenleme Formu"
    this.modalAc(this.modalGemiTipiTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.gemiTipiTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.gemiTipiTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.gemiTipiListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async gemiTipiSilButton(secilenKayit) {
    Swal.fire({
      title               : "Gemi Tipi Silinecek",
      text                : "Gemi Tipi Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.gemiTipiSil(secilenKayit)
      }
    })
  }

  async gemiTipiSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'gemiTipiTanimlari/gemiTipiSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.gemiTipiTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.gemiTipiTanimlari.splice(i, 1)
        if (this.gemiTipiTanimlari.length == 0) { this.gemiTipiTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}


