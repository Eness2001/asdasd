import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-odemeTipiTanimlari',
  templateUrl: './odemeTipiTanimlari.html'
})


export class odemeTipiTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalOdemeTipiTanimlari') modalOdemeTipiTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Ödeme Tipi Tanımları")
    this.bs.change(['Ayarlar', 'Grup Tanımları'])
    this.ödemeTipiListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  odemeTipiTanimlariFormu = new FormGroup({
    islem                   : new FormControl(''),
    method                  : new FormControl(''),
    e_sira                  : new FormControl(''),
    e_odeme_aciklamasi_tr   : new FormControl(''),
    e_odeme_aciklamasi_en   : new FormControl(''),
    e_odeme_kodu            : new FormControl(''),
    ESKI_ID                 : new FormControl('')
  })

  requestData
  responseData

  odemeTipiTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async ödemeTipiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "odemeTipiTanimlari/odemeTipiListesi", {})
    if (this.responseData.DATA.length == 0) { this.odemeTipiTanimlari = null } else {this.odemeTipiTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async odemeTipiEkleButton() {
    this.odemeTipiTanimlariFormu.patchValue({
      islem           : 'odemeTipiTanimlari/odemeTipiEkle',
      method          : 'POST',
      e_sira                  : '',
      e_odeme_aciklamasi_tr   : '',
      e_odeme_aciklamasi_en   : '',
      e_odeme_kodu            : ''
    })
    this.modalHeader.title = "Ödeme Tipi Ekleme Formu"
    this.modalAc(this.modalOdemeTipiTanimlari, 'md')
  }

  async odemeTipiDuzenleButton(secilenKayit) {
    this.odemeTipiTanimlariFormu.patchValue({
      islem                   : 'odemeTipiTanimlari/odemeTipiDuzenle',
      method                  : 'PUT',
      e_sira                  : secilenKayit.e_sira,
      e_odeme_aciklamasi_tr   : secilenKayit.e_odeme_aciklamasi_tr,
      e_odeme_aciklamasi_en   : secilenKayit.e_odeme_aciklamasi_en,
      e_odeme_kodu            : secilenKayit.e_odeme_kodu,
      ESKI_ID                 : secilenKayit.e_id
    })
    this.modalHeader.title = "Ödeme Tipi Düzenleme Formu"
    this.modalAc(this.modalOdemeTipiTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.odemeTipiTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.odemeTipiTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.ödemeTipiListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async odemeTipiSilButton(secilenKayit) {
    Swal.fire({
      title               : "Ödeme Tipi Silinecek",
      text                : "Ödeme Tipi Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.odemeTipiSil(secilenKayit)
      }
    })
  }

  async odemeTipiSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'odemeTipiTanimlari/odemeTipiSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.odemeTipiTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.odemeTipiTanimlari.splice(i, 1)
        if (this.odemeTipiTanimlari.length == 0) { this.odemeTipiTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}


