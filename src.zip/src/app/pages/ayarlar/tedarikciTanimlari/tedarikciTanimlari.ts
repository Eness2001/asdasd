import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'
import { il_ilce_data } from 'src/app/shared/data/il_ilce'

@Component({
  selector: 'app-tedarikciTanimlari',
  templateUrl: './tedarikciTanimlari.html'
})


export class tedarikciTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
    private il_ilce_data : il_ilce_data
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalTedarikciTanimlari') modalTedarikciTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Tedarikci Tanımları")
    this.bs.change(['Ayarlar', 'Tedarikci Tanımları'])
    this.tedarikciListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  tedarikciTanimlariFormu = new FormGroup({
    islem           : new FormControl(''),
    method          : new FormControl(''),
    e_firma_unvani  : new FormControl(''),
    e_ilgili_kisi   : new FormControl(''),
    e_telefon       : new FormControl(''),
    e_mail          : new FormControl(''),
    e_il            : new FormControl(''),
    e_ilce          : new FormControl(''),
    e_adres         : new FormControl(''),
    e_vergi_dairesi : new FormControl(''),
    e_vergi_numarasi: new FormControl(''),
    e_not           : new FormControl(''),
    ESKI_ID         : new FormControl('')
  })

  requestData
  responseData

  tedarikciTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  iller = this.il_ilce_data.ilGetir()
  ilceler 

  async tedarikciListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "tedarikciTanimlari/tedarikciListesi", {})
    if (this.responseData.DATA.length == 0) { this.tedarikciTanimlari = null } else {this.tedarikciTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async tedarikciEkleButton() {
    this.tedarikciTanimlariFormu.patchValue({
      islem             : 'tedarikciTanimlari/tedarikciEkle',
      method            : 'POST',
      e_firma_unvani    : '',
      e_ilgili_kisi     : '',
      e_telefon         : '',
      e_mail            : '',
      e_il              : '',
      e_ilce            : '',
      e_adres           : '',
      e_vergi_dairesi   : '',
      e_vergi_numarasi  : '',
      e_not             : '',
    })
    this.modalHeader.title = "Tedarikci Ekleme Formu"
    this.modalAc(this.modalTedarikciTanimlari, 'md')
  }

  async tedarikciDuzenleButton(secilenKayit) {
    this.tedarikciTanimlariFormu.patchValue({
      islem             : 'tedarikciTanimlari/tedarikciDuzenle',
      method            : 'PUT',
      e_firma_unvani    : secilenKayit.e_firma_unvani,
      e_ilgili_kisi     : secilenKayit.e_ilgili_kisi,
      e_telefon         : secilenKayit.e_telefon,
      e_mail            : secilenKayit.e_mail,
      e_il              : secilenKayit.e_il,
      e_ilce            : secilenKayit.e_ilce,
      e_adres           : secilenKayit.e_adres,
      e_vergi_dairesi   : secilenKayit.e_vergi_dairesi,
      e_vergi_numarasi  : secilenKayit.e_vergi_numarasi,
      e_not             : secilenKayit.e_not,
      ESKI_ID           : secilenKayit.e_id
    })
    this.modalHeader.title = "Tedarikci Düzenleme Formu"
    this.modalAc(this.modalTedarikciTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.tedarikciTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.tedarikciTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.tedarikciListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async tedarikciSilButton(secilenKayit) {
    Swal.fire({
      title               : "Tedarikci Silinecek",
      text                : "Tedarikci Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.tedarikciSil(secilenKayit)
      }
    })
  }

  async tedarikciSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'tedarikciTanimlari/tedarikciSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.tedarikciTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.tedarikciTanimlari.splice(i, 1)
        if (this.tedarikciTanimlari.length == 0) { this.tedarikciTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
}

  onIlChange(event : any) {
  const selectedIl = event.target.value;  
  this.ilceler = this.il_ilce_data.ilceGetir(selectedIl); 
  
  }

}


