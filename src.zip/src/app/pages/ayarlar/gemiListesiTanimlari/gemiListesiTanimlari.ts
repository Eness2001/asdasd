import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'


@Component({
  selector: 'app-malzemeTanimlari',
  templateUrl: './gemiListesiTanimlari.html'
})


export class gemiListesiTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalGemiListesiTanimlari') modalGemiListesiTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Malzeme Tanımları")
    this.bs.change(['Ayarlar', 'Malzeme Tanımları'])
    this.grupFirmaListele()
    this.gemiListesiListele()
    this.gemiTipiListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  gemiListesiTanimlariFormu = new FormGroup({
    islem                    : new FormControl(''),
    method                   : new FormControl(''),
    e_bagli_oldugu_sirket_id : new FormControl(''),
    e_gemi_tipi_id           : new FormControl(''),
    e_gemi_adi               : new FormControl(''),
    e_imo_no                 : new FormControl(''),
    e_bayrak                 : new FormControl(''),
    e_filo_no                : new FormControl(''),
    e_min_kar_orani          : new FormControl(''),
    e_not                    : new FormControl(''),
    ESKI_ID                  : new FormControl('')
  })

  filterData = {
    ARAMA   : '',
    SS      : 1,
    KS      : 20,
    e_durum : 'Aktif'
  }

  requestData
  responseData

  gemiListesiTanimlari
  gemiTipiTanimlari
  grupFirmaTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async gemiListesiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "gemiListesi/gemiListesi", this.filterData)
    console.log(this.responseData);
    
    if (this.responseData.DATA.length == 0) { this.gemiListesiTanimlari = null } else {this.gemiListesiTanimlari = this.responseData.DATA}
    this.kayitSayisi = this.responseData.TKS
    this.mainLoader = false
  }

  async gemiListesiEkleButton() {
    this.gemiListesiTanimlariFormu.patchValue({
      islem                    : 'gemiListesi/gemiEkle',
      method                   : 'POST',
      e_bagli_oldugu_sirket_id :'',
      e_gemi_tipi_id           :'',
      e_gemi_adi               :'',
      e_imo_no                 :'',
      e_bayrak                 :'',
      e_filo_no                :'',
      e_min_kar_orani          :'',
      e_not                    :'',
    }) 
    this.modalHeader.title = "Gemi Listesi Ekleme Formu"
    this.modalAc(this.modalGemiListesiTanimlari, 'md')
  }

  async gemiListesiDuzenleButton(secilenKayit) {
    this.gemiListesiTanimlariFormu.patchValue({
      islem                     : 'gemiListesi/gemiDuzenle',
      method                    : 'PUT',
      e_bagli_oldugu_sirket_id  : secilenKayit.e_bagli_oldugu_sirket_id,
      e_gemi_tipi_id            : secilenKayit.e_gemi_tipi_id,
      e_gemi_adi                : secilenKayit.e_gemi_adi,
      e_imo_no                  : secilenKayit.e_imo_no,
      e_bayrak                  : secilenKayit.e_bayrak,
      e_filo_no                 : secilenKayit.e_filo_no,
      e_min_kar_orani           : secilenKayit.e_min_kar_orani,
      e_not                     : secilenKayit.e_not,
      ESKI_ID                   : secilenKayit.e_id
    })
    this.modalHeader.title = "Gemi Listesi Düzenleme Formu"
    this.modalAc(this.modalGemiListesiTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {  
    if (this.gemiListesiTanimlariFormu.valid) {
      this.islemiKaydetBtn = true
      this.requestData = Object.assign({}, this.gemiListesiTanimlariFormu.value)
      console.log(this.requestData);
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.gemiListesiListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async gemiListesiSilButton(secilenKayit) {
    Swal.fire({
      title               : "Gemi Listesi Silinecek",
      text                : "Gemi Listesi Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.gemiListesiSil(secilenKayit)
      }
    })
  }

  async gemiListesiSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'gemiListesi/gemiSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.gemiListesiTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.gemiListesiTanimlari.splice(i, 1)
        if (this.gemiListesiTanimlari.length == 0) { this.gemiListesiTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

  
  async grupFirmaListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "grupFirmaTanimlari/grupFirmaListesi", {})
    if (this.responseData.DATA.length == 0) { this.grupFirmaTanimlari = null } else {this.grupFirmaTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async gemiTipiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "gemiTipiTanimlari/gemiTipiListesi", {})
    if (this.responseData.DATA.length == 0) { this.gemiTipiTanimlari = null } else {this.gemiTipiTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }


}


