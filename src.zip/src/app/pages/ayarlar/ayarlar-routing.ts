import { NgModule } from '@angular/core'
import { Routes, RouterModule } from '@angular/router'
import { kullaniciTanimlariComponent } from './kullaniciTanimlari/kullaniciTanimlari'
import { birimTanimlariComponent } from './birimTanimlari/birimTanimlari'
import { grupTanimlariComponent } from './grupTanimlari/grupTanimlari'
import { odemeTipiTanimlariComponent } from './odemeTipiTanimlari/odemeTipiTanimlari'
import { teslimKosuluTanimlariComponent } from './teslimKosuluTanimlari/teslimKosuluTanimlari'
import { teslimYeriTanimlariComponent } from './teslimYeriTanimlari/teslimYeriTanimlari'
import { malzemeTanimlariComponent } from './malzemeTanimlari/malzemeTanimlari'
import { firmaTipiTanimlariComponent } from './firmaTipiTanimlari/firmaTipiTanimlari'
import { grupFirmaTanimlariComponent } from './grupFirmaTanimlari/grupFirmaTanimlari'
import { gemiTipiTanimlariComponent } from './gemiTipiTanimlari/gemiTipiTanimlari'
import { tedarikciTanimlariComponent } from './tedarikciTanimlari/tedarikciTanimlari'
import { musteriTanimlariComponent } from './müsteriTanimlari/musteriTanimlari'
import { gemiListesiTanimlariComponent } from './gemiListesiTanimlari/gemiListesiTanimlari'
import { musteriDetayTanimlariComponent } from './musteriDetayTanimlari/musteriDetayTanimlari'

const routes: Routes = [{
    path: 'kullaniciTanimlari',
    component: kullaniciTanimlariComponent
  },  {
    path: 'birimTanimlari',
    component: birimTanimlariComponent
  }, {
    path: 'grupTanimlari',
    component: grupTanimlariComponent
  }, {
    path: 'odemeTipiTanimlari',
    component: odemeTipiTanimlariComponent
  }, {
    path: 'teslimKosuluTanimlari',
    component: teslimKosuluTanimlariComponent
  }, {
    path: 'teslimYeriTanimlari',
    component: teslimYeriTanimlariComponent
  }, {
    path: 'malzemeTanimlari',
    component: malzemeTanimlariComponent
  }, {
    path: 'firmaTipiTanimlari',
    component: firmaTipiTanimlariComponent
  }, {
    path: 'grupFirmaTanimlari',
    component: grupFirmaTanimlariComponent
  }, {
    path: 'gemiTipiTanimlari',
    component: gemiTipiTanimlariComponent
  }, {
    path: 'tedarikciTanimlari',
    component: tedarikciTanimlariComponent
  }, {
    path: 'musteriTanimlari',
    component: musteriTanimlariComponent
  }, {
    path: 'gemiListesiTanimlari',
    component: gemiListesiTanimlariComponent
  }, {
    path: 'musteriDetayTanimlari/:id',
    component: musteriDetayTanimlariComponent
  }
]

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ayarlarRoutingModule { }