import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'


@Component({
  selector: 'app-malzemeTanimlari',
  templateUrl: './malzemeTanimlari.html'
})


export class malzemeTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalMalzemeTanimlari') modalMalzemeTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Malzeme Tanımları")
    this.bs.change(['Ayarlar', 'Malzeme Tanımları'])
    this.malzemeListele()
    this.birimListele()
    this.grupListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  malzemeTanimlariFormu = new FormGroup({
    islem              : new FormControl(''),
    method             : new FormControl(''),
    e_grup_id          : new FormControl(''),
    e_birim_id         : new FormControl(''),
    e_malzeme_kodu     : new FormControl(''),
    e_impa_kodu        : new FormControl(''),
    e_malzeme_adi_tr   : new FormControl(''),
    e_malzeme_adi_en   : new FormControl(''),
    e_aciklama         : new FormControl(''),
    ESKI_ID            : new FormControl('')
  })

  filterData = {
    ARAMA   : '',
    SS      : 1,
    KS      : 20,
    e_durum : 'Aktif'
  }

  requestData
  responseData

  malzemeTanimlari
  birimTanimlari
  grupTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async malzemeListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "malzemeTanimlari/malzemeListesi", this.filterData)
    console.log(this.responseData);
    
    if (this.responseData.DATA.length == 0) { this.malzemeTanimlari = null } else {this.malzemeTanimlari = this.responseData.DATA}
    this.kayitSayisi = this.responseData.TKS
    this.mainLoader = false
  }

  async malzemeEkleButton() {
    this.malzemeTanimlariFormu.patchValue({
      islem           : 'malzemeTanimlari/malzemeEkle',
      method          : 'POST',
      e_grup_id             :'',
      e_birim_id            :'',
      e_malzeme_kodu        :'',
      e_impa_kodu           :'',
      e_malzeme_adi_tr      :'',
      e_malzeme_adi_en      :'',
      e_aciklama            :'',
    })
    console.log(this.malzemeTanimlariFormu);
    
    this.modalHeader.title = "Malzeme Ekleme Formu"
    this.modalAc(this.modalMalzemeTanimlari, 'md')
  }

  async malzemeDuzenleButton(secilenKayit) {
    this.malzemeTanimlariFormu.patchValue({
      islem            : 'malzemeTanimlari/malzemeEkle',
      method           : 'PUT',
      e_grup_id        : secilenKayit.e_grup_id,
      e_birim_id       : secilenKayit.e_birim_id,
      e_malzeme_kodu   : secilenKayit.e_malzeme_kodu,
      e_impa_kodu      : secilenKayit.e_impa_kodu,
      e_malzeme_adi_tr : secilenKayit.e_malzeme_adi_tr,
      e_malzeme_adi_en : secilenKayit.e_malzeme_adi_en,
      e_aciklama       : secilenKayit.e_aciklama,
      ESKI_ID          : secilenKayit.e_id
    })
    this.modalHeader.title = "Grup Düzenleme Formu"
    this.modalAc(this.modalMalzemeTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {  
    if (this.malzemeTanimlariFormu.valid) {
      this.islemiKaydetBtn = true
      console.log(this.malzemeTanimlariFormu.value.e_grup_id);
      
      this.requestData = Object.assign({}, this.malzemeTanimlariFormu.value)
      console.log(this.requestData);
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.malzemeListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async malzemeSilButton(secilenKayit) {
    Swal.fire({
      title               : "Birim Silinecek",
      text                : "Birim Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.malzemeSil(secilenKayit)
      }
    })
  }

  async malzemeSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'malzemeTanimlari/malzemeSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.malzemeTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.malzemeTanimlari.splice(i, 1)
        if (this.malzemeTanimlari.length == 0) { this.malzemeTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

  
  async birimListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "birimTanimlari/birimListesi", {})
    if (this.responseData.DATA.length == 0) { this.birimTanimlari = null } else {this.birimTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async grupListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "grupTanimlari/grupListesi", {})
    if (this.responseData.DATA.length == 0) { this.grupTanimlari = null } else {this.grupTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }


}


