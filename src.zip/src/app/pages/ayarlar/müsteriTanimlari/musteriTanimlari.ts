import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'
import { il_ilce_data } from 'src/app/shared/data/il_ilce'
import { ulke_data } from 'src/app/shared/data/ulke'
import { Router } from '@angular/router';


@Component({
  selector: 'app-musteriTanimlari',
  templateUrl: './musteriTanimlari.html'
})


export class musteriTanimlariComponent implements OnInit {
  constructor(
    public  islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public  modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
    private il_ilce_data : il_ilce_data,
    private ulke_data : ulke_data ,
    private router: Router
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalMusteriTanimlari') modalMusteriTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Musteri Tanımları")
    this.bs.change(['Ayarlar', 'Musteri Tanımları'])
    this.musteriListele()
    this.firmaTipiListele()
    this.grupFirmaListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  musteriTanimlariFormu = new FormGroup({
    islem              : new FormControl(''),
    method             : new FormControl(''),
    e_firma_grup_id    : new FormControl(''),
    e_cari_ismi        : new FormControl(''),
    e_mail             : new FormControl(''),
    e_telefon          : new FormControl(''),
    e_il               : new FormControl(''),
    e_adres            : new FormControl(''),
    e_ulke             : new FormControl(''),
    e_firma_tipi_id    : new FormControl(''),
    e_not              : new FormControl(''),
    ESKI_ID            : new FormControl('')
  })

  filterData = {
    ARAMA   : '',
    SS      : 1,
    KS      : 20,
    e_durum : 'Aktif'
  }

  requestData
  responseData

  musteriTanimlari
  grupFirmaTanimlari
  firmaTipiTanimlari

  iller = this.il_ilce_data.ilGetir()
  ulkeler = this.ulke_data.ulkeGetir()[0]
  
  
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async musteriListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "musteriListesi/musteriListesi", this.filterData)
   console.log(this.responseData);
   
   
    
    if (this.responseData.DATA.length == 0) { this.musteriTanimlari = null } else {this.musteriTanimlari = this.responseData.DATA}
    this.kayitSayisi = this.responseData.TKS
    this.mainLoader = false
  }

  async musteriDetayGetir(secilenKayit) {
 
console.log(secilenKayit);

    this.responseData = await this.islem.WebServisSorguSonucu("GET", `musteriListesi/musteriListesi?ESKI_ID=12${secilenKayit.e_id}`, this.responseData.DATA);
    console.log(this.responseData);
  }

  async musteriEkleButton() {
    this.musteriTanimlariFormu.patchValue({
      islem           : 'musteriListesi/musteriEkle',
      method          : 'POST',
      e_firma_grup_id :'',
      e_cari_ismi     :'',
      e_mail          :'',
      e_telefon       :'',
      e_il            :'',
      e_adres         :'',
      e_ulke          :'',
      e_firma_tipi_id :'',
      e_not           :'',
    })
    
    this.modalHeader.title = "Müşteri Ekleme Formu"
    this.modalAc(this.modalMusteriTanimlari, 'md')
  }

  async musteriDuzenleButton(secilenKayit) {
    this.musteriTanimlariFormu.patchValue({
      islem            : 'musteriListesi/musteriDuzenle',
      method           : 'PUT',
      e_firma_grup_id  : secilenKayit.e_grup_id,
      e_cari_ismi      : secilenKayit.e_birim_id,
      e_mail           : secilenKayit.e_malzeme_kodu,
      e_telefon        : secilenKayit.e_impa_kodu,
      e_il             : secilenKayit.e_malzeme_adi_tr,
      e_adres          : secilenKayit.e_malzeme_adi_en,
      e_ulke           : secilenKayit.e_aciklama,
      e_firma_tipi_id  : secilenKayit.e_aciklama,
      e_not            : secilenKayit.e_aciklama,
      ESKI_ID          : secilenKayit.e_id
    })
    this.modalHeader.title = "Müşteri Düzenleme Formu"
    this.modalAc(this.modalMusteriTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {  
    if (this.musteriTanimlariFormu.valid) {
      this.islemiKaydetBtn = true
      this.requestData = Object.assign({}, this.musteriTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.musteriListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async musteriSilButton(secilenKayit) {
    Swal.fire({
      title               : "Müşteri Silinecek",
      text                : "Müşteri Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.musteriSil(secilenKayit)
      }
    })
  }

  async musteriDetayButton(secilenKayit) {
    console.log(secilenKayit);
    
    this.musteriDetayGetir(secilenKayit)
  }

  async musteriSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'musteriListesi/musteriSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.musteriTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.musteriTanimlari.splice(i, 1)
        if (this.musteriTanimlari.length == 0) { this.musteriTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }


  async grupFirmaListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "grupFirmaTanimlari/grupFirmaListesi", {})
    if (this.responseData.DATA.length == 0) { this.grupFirmaTanimlari = null } else {this.grupFirmaTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async firmaTipiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "firmaTipiTanimlari/firmaTipiListesi", {})
    if (this.responseData.DATA.length == 0) { this.firmaTipiTanimlari = null } else {this.firmaTipiTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  musteriDetaySayfasinaGitButton(id) {
    console.log(id);
    this.router.navigateByUrl('ayarlar/musteriDetayTanimlari/' + id);
    
  }


}


