import { NgModule } from '@angular/core'
import { CommonModule } from '@angular/common'
import { FormsModule , ReactiveFormsModule } from '@angular/forms'
import { NgbModule, NgbPaginationModule } from '@ng-bootstrap/ng-bootstrap'
import { ayarlarRoutingModule } from './ayarlar-routing'

import { FormDirective } from './ayarlar-directive'
import { TranslateModule } from '@ngx-translate/core'
import { NgxMaskDirective, NgxMaskPipe, provideNgxMask } from 'ngx-mask';
import { AgGridModule } from 'ag-grid-angular';


import { birimTanimlariComponent } from './birimTanimlari/birimTanimlari'
import { odemeTipiTanimlariComponent } from './odemeTipiTanimlari/odemeTipiTanimlari'
import { teslimYeriTanimlariComponent } from './teslimYeriTanimlari/teslimYeriTanimlari'
import { teslimKosuluTanimlariComponent } from './teslimKosuluTanimlari/teslimKosuluTanimlari'
import { kullaniciTanimlariComponent } from './kullaniciTanimlari/kullaniciTanimlari'
import { grupTanimlariComponent } from './grupTanimlari/grupTanimlari'
import { malzemeTanimlariComponent } from './malzemeTanimlari/malzemeTanimlari'
import { firmaTipiTanimlariComponent } from './firmaTipiTanimlari/firmaTipiTanimlari'
import { grupFirmaTanimlariComponent } from './grupFirmaTanimlari/grupFirmaTanimlari'
import { gemiTipiTanimlariComponent } from './gemiTipiTanimlari/gemiTipiTanimlari'
import { tedarikciTanimlariComponent } from './tedarikciTanimlari/tedarikciTanimlari'
import { musteriTanimlariComponent } from './müsteriTanimlari/musteriTanimlari'
import { gemiListesiTanimlariComponent } from './gemiListesiTanimlari/gemiListesiTanimlari'
import { musteriDetayTanimlariComponent } from './musteriDetayTanimlari/musteriDetayTanimlari'

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ayarlarRoutingModule,
    NgbPaginationModule,
    NgbModule,
    TranslateModule,
    NgxMaskDirective,
    NgxMaskPipe,
    AgGridModule,
    
  ],
  declarations: [
    kullaniciTanimlariComponent,
    birimTanimlariComponent,
    grupTanimlariComponent,
    odemeTipiTanimlariComponent,
    teslimKosuluTanimlariComponent,
    teslimYeriTanimlariComponent,
    malzemeTanimlariComponent,
    firmaTipiTanimlariComponent,
    grupFirmaTanimlariComponent,
    gemiTipiTanimlariComponent,
    tedarikciTanimlariComponent,
    musteriTanimlariComponent,
    gemiListesiTanimlariComponent,
    musteriDetayTanimlariComponent,
    FormDirective
  ],
  providers: [
    provideNgxMask(),
  ]
})

export class ayarlarModule {}