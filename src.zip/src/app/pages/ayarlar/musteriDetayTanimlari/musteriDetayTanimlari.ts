import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'
import { il_ilce_data } from 'src/app/shared/data/il_ilce'
import { ulke_data } from 'src/app/shared/data/ulke'
import { ActivatedRoute } from "@angular/router";



@Component({
  selector: 'app-musteriTanimlari',
  templateUrl: './musteriDetayTanimlari.html'
})


export class musteriDetayTanimlariComponent implements OnInit {
  constructor(
    public  islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public  modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
    private il_ilce_data : il_ilce_data,
    private ulke_data : ulke_data ,
    private activatedRoute: ActivatedRoute,

  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalMusteriTanimlari') modalMusteriTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Musteri Tanımları")
    this.bs.change(['Ayarlar', 'Musteri Tanımları'])
    this.musteriDetayiListele()
    this.grupFirmaListele()
    this.firmaTipiListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  musteriDetayiTanimlariFormu = new FormGroup({
    islem              : new FormControl('musteriListesi/musteriDuzenle'),
    method             : new FormControl('PUT'),
    e_firma_grup_id    : new FormControl(''),
    e_cari_ismi        : new FormControl(''),
    e_mail             : new FormControl(''),
    e_telefon          : new FormControl(''),
    e_il               : new FormControl(''),
    e_adres            : new FormControl(''),
    e_ulke             : new FormControl(''),
    e_firma_tipi_id    : new FormControl(''),
    e_not              : new FormControl(''),
    ESKI_ID            : new FormControl(this.activatedRoute.snapshot.paramMap.get('id'))
  })

  filterData = {
    ESKI_ID: this.activatedRoute.snapshot.paramMap.get('id'),
  }

  requestData
  responseData

  grupFirmaTanimlari
  firmaTipiTanimlari
  musteriDetaylari
  musteriTanimlari

  iller = this.il_ilce_data.ilGetir()
  ulkeler = this.ulke_data.ulkeGetir()[0]
  
  
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async musteriListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "musteriListesi/musteriListesi", this.filterData)
    if (this.responseData.DATA.length == 0) { this.musteriTanimlari = null } else {this.musteriTanimlari = this.responseData.DATA}
    this.kayitSayisi = this.responseData.TKS
    this.mainLoader = false
  }



  async musteriEkleButton() {
    this.musteriDetayiTanimlariFormu.patchValue({
      islem           : 'musteriListesi/musteriEkle',
      method          : 'POST',
      e_firma_grup_id :'',
      e_cari_ismi     :'',
      e_mail          :'',
      e_telefon       :'',
      e_il            :'',
      e_adres         :'',
      e_ulke          :'',
      e_firma_tipi_id :'',
      e_not           :'',
    })
    
    this.modalHeader.title = "Müşteri Ekleme Formu"
    this.modalAc(this.modalMusteriTanimlari, 'md')
  }

  async musteriDuzenleButton() {
        this.islemiKaydetBtn = true
        const requestData = this.musteriDetayiTanimlariFormu.value;   
        this.responseData = await this.islem.WebServisSorguSonucu(requestData.method, requestData.islem, requestData)
  
        if (this.responseData.S == "T") {
          this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
          this.musteriListele()
          this.modalService.dismissAll()
        } else {
          this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
        }
  
        this.islemiKaydetBtn = false
  }

  async islemiKaydet(): Promise<void> {  
    if (this.musteriDetayiTanimlariFormu.valid) {
      this.islemiKaydetBtn = true
      this.requestData = Object.assign({}, this.musteriDetayiTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.musteriListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async musteriSilButton(secilenKayit) {
    Swal.fire({
      title               : "Müşteri Silinecek",
      text                : "Müşteri Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.musteriSil(secilenKayit)
      }
    })
  }

  

  async musteriSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'musteriListesi/musteriSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.musteriTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.musteriTanimlari.splice(i, 1)
        if (this.musteriTanimlari.length == 0) { this.musteriTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

  async grupFirmaListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "grupFirmaTanimlari/grupFirmaListesi", {})
    if (this.responseData.DATA.length == 0) { this.grupFirmaTanimlari = null } else {this.grupFirmaTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }




  async musteriDetayiListele(){
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "musteriListesi/musteriListesi", this.filterData)

    
      if (this.responseData.DATA.length == 0) { this.musteriDetaylari = null } else { 
          this.musteriDetaylari = this.responseData.DATA[0]
          
          this.musteriDetayiTanimlariFormu.patchValue({
            e_firma_grup_id    : this.responseData.DATA[0].e_firma_grup_id,
            e_cari_ismi  : this.responseData.DATA[0].e_cari_ismi  ,
            e_firma_tipi_id           : this.responseData.DATA[0].e_firma_tipi_id,
            e_adres : this.responseData.DATA[0].e_adres,
            e_il : this.responseData.DATA[0].e_il,
            e_mail : this.responseData.DATA[0].e_mail,
            e_not : this.responseData.DATA[0].e_not,
            e_telefon : this.responseData.DATA[0].e_telefon,
            e_ulke : this.responseData.DATA[0].e_ulke,
          })
        }
    this.mainLoader = false
  }

  async firmaTipiListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "firmaTipiTanimlari/firmaTipiListesi", {})
    if (this.responseData.DATA.length == 0) { this.firmaTipiTanimlari = null } else {this.firmaTipiTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

}


