import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'
import { ulke_data } from 'src/app/shared/data/ulke'

@Component({
  selector: 'app-kullaniciTanimlari',
  templateUrl: './kullaniciTanimlari.html'
})


export class kullaniciTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
    private ulke_data: ulke_data
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalkullaniciTanimlari') modalkullaniciTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Kullanıcı Tanımları")
    this.bs.change(['Ayarlar', 'Kullanıcı Tanımları'])
    this.kullaniciListele()

    this.kullaniciTanimlariFormu.controls['e_sifre'].valueChanges.subscribe((val) => {
      this.parolaKontrolEt(val)
    })
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  kullaniciTanimlariFormu = new FormGroup({
    islem                           : new FormControl(''),
    method                          : new FormControl(''),
    e_kullanici_adi                 : new FormControl(''),
    e_sifre                         : new FormControl(''),
    e_personel_adi                  : new FormControl(''),
    e_durum                         : new FormControl(''),
    e_departman                     : new FormControl(''),
    e_ulke                          : new FormControl(''),
    ESKI_ID                         : new FormControl('')
  })

  filterData = {
    ARAMA   : '',
    SS      : 1,
    KS      : 20,
    e_durum : 'Aktif'
  }

  requestData
  responseData

  kullaniciTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  ulkeler = this.ulke_data.ulkeGetir()

  async kullaniciListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "kullaniciTanimlari/kullaniciListesi", this.filterData)
    if (this.responseData.DATA.length == 0) { this.kullaniciTanimlari = null } else {this.kullaniciTanimlari = this.responseData.DATA}
    this.kayitSayisi = this.responseData.TKS
    this.mainLoader = false
  }

  async kullaniciEkleButton() {
    this.kullaniciTanimlariFormu.patchValue({
      islem                         : 'kullaniciTanimlari/kullaniciEkle',
      method                        : 'POST',
      e_personel_adi                : '',
      e_kullanici_adi               : '',
      e_sifre                       : '',
      e_departman                   : '',
      e_ulke                        : '',
      e_durum                       : 'Aktif'
    })
    this.modalHeader.title = "Kullanıcı Ekleme Formu"
    this.modalAc(this.modalkullaniciTanimlari, 'md')
  }

  async kullaniciDuzenleButton(secilenKayit) {
    this.kullaniciTanimlariFormu.patchValue({
      islem                         : 'kullaniciTanimlari/kullaniciDuzenle',
      method                        : 'PUT',
      e_kullanici_adi               : secilenKayit.e_kullanici_adi,
      e_sifre                       : secilenKayit.e_sifre,
      e_personel_adi                : secilenKayit.e_personel_adi,
      e_durum                       : secilenKayit.e_durum,
      e_departman                   : secilenKayit.e_departman,
      e_ulke                        : secilenKayit.e_ulke,
      ESKI_ID                       : secilenKayit.e_id
    })
    this.modalHeader.title = "Kullanıcı Düzenleme Formu"
    this.modalAc(this.modalkullaniciTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.kullaniciTanimlariFormu.valid && this.parolaBarKontrol == "success") {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.kullaniciTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.kullaniciListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async kullaniciSilButton(secilenKayit) {
    Swal.fire({
      title               : "Kullanıcı Silinecek",
      text                : "Kullanıcı Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.kullaniciSil(secilenKayit)
      }
    })
  }

  async kullaniciSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE",  'kullaniciTanimlari/kullaniciSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.kullaniciTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.kullaniciTanimlari.splice(i, 1)
        if (this.kullaniciTanimlari.length == 0) { this.kullaniciTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

  parolaKontrol = 0
  parolaBarKontrol = ""
  buyukKucukHarfKontrol = false
  sayiKontrol = false
  ozelKarakterKontrol = false
  uzunlukKontrol = false

  parolaKontrolEt(val){
    this.parolaKontrol = 0

    //Parola küçük büyük harf kontrolü.
    if (val.match(/([a,b,c,ç,d,e,f,g,ğ,h,i,ı,j,k,l,m,n,o,ö,p,r,s,ş,t,u,ü,v,y,z].*[A,B,C,Ç,D,E,F,G,Ğ,H,İ,I,J,K,L,M,N,O,Ö,P,R,S,Ş,T,U,Ü,V,Y,Z])|([A,B,C,Ç,D,E,F,G,Ğ,H,İ,I,J,K,L,M,N,O,Ö,P,R,S,Ş,T,U,Ü,V,Y,Z].*[a,b,c,ç,d,e,f,g,ğ,h,i,ı,j,k,l,m,n,o,ö,p,r,s,ş,t,u,ü,v,y,z])/)) {
      this.parolaKontrol += 1;
      this.buyukKucukHarfKontrol = true
    } else {
      this.buyukKucukHarfKontrol = false
    }

    //Parola sayı kontrolü
    if (val.match(/([0-9])/)) {
      this.parolaKontrol += 1;
      this.sayiKontrol = true
    } else {
      this.sayiKontrol = false
    }

    //Parola özel karakter kontrolü
    if (val.match(/([!,%,&,@,#,$,^,*,?,_,~])/)) {
      this.parolaKontrol += 1;
      this.ozelKarakterKontrol = true
    } else {
      this.ozelKarakterKontrol = false
    }

    //Parola uzunluk kontrolü
    if (val.length > 7) {
      this.parolaKontrol += 1;
      this.uzunlukKontrol = true
    } else {
      this.uzunlukKontrol = false
    }

    // If value is less than 2
    if (this.parolaKontrol < 2) {
      this.parolaBarKontrol = "danger"
    } else if (this.parolaKontrol == 3) {
      this.parolaBarKontrol = "warning"
    } else if (this.parolaKontrol == 4) {
      this.parolaBarKontrol = "success"
    }
  }
}