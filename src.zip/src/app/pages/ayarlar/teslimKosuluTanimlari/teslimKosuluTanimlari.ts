import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-teslimKosuluTanimlari',
  templateUrl: './teslimKosuluTanimlari.html'
})


export class teslimKosuluTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalTeslimKosuluTanimlari') modalTeslimKosuluTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Teslimat Kosulu Tanımları")
    this.bs.change(['Ayarlar', 'Teslimat Kosulu Tanımları'])
    this.teslimKosuluListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  teslimKosuluTanimlariFormu = new FormGroup({
    islem                : new FormControl(''),
    method               : new FormControl(''),
    e_sira               : new FormControl(''),
    e_teslim_kosulu_tr   : new FormControl(''),
    e_teslim_kosulu_en   : new FormControl(''),
    ESKI_ID              : new FormControl('')
  })

  requestData
  responseData

  teslimKosuluTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async teslimKosuluListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "teslimKosuluTanimlari/teslimKosuluListesi", {})
    if (this.responseData.DATA.length == 0) { this.teslimKosuluTanimlari = null } else {this.teslimKosuluTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async teslimKosuluEkleButton() {
    this.teslimKosuluTanimlariFormu.patchValue({
      islem                : 'grupTanimlari/grupEkle',
      method               : 'POST',
      e_sira               : '',
      e_teslim_kosulu_en   : '',
      e_teslim_kosulu_tr   : ''
    })
    this.modalHeader.title = "Grup Ekleme Formu"
    this.modalAc(this.modalTeslimKosuluTanimlari, 'md')
  }

  async teslimKosuluDuzenleButton(secilenKayit) {
    this.teslimKosuluTanimlariFormu.patchValue({
      islem              : 'grupTanimlari/grupDuzenle',
      method             : 'PUT',
      e_sira             : secilenKayit.e_sira,
      e_teslim_kosulu_tr : secilenKayit.e_teslim_kosulu_tr,
      e_teslim_kosulu_en : secilenKayit.e_teslim_kosulu_en,
      ESKI_ID            : secilenKayit.e_id
    })
    this.modalHeader.title = "Grup Düzenleme Formu"
    this.modalAc(this.modalTeslimKosuluTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.teslimKosuluTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.teslimKosuluTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.teslimKosuluListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async teslimKosuluSilButton(secilenKayit) {
    Swal.fire({
      title               : "Teslim Kosulu Silinecek",
      text                : "Teslim Kosulu Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.teslimKosuluSil(secilenKayit)
      }
    })
  }

  async teslimKosuluSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'teslimKosuluTanimlari/teslimKosuluSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.teslimKosuluTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.teslimKosuluTanimlari.splice(i, 1)
        if (this.teslimKosuluTanimlari.length == 0) { this.teslimKosuluTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}


