import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-birimTanimlari',
  templateUrl: './grupFirmaTanimlari.html'
})


export class grupFirmaTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalGrupFirmaTanimlari') modalGrupFirmaTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Grup Firma Tanımları")
    this.bs.change(['Ayarlar', 'Grup Firma Tanımları'])
    this.grupFirmaListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  grupFirmaTanimlariFormu = new FormGroup({
    islem            : new FormControl(''),
    method           : new FormControl(''),
    e_grup_firma_adi : new FormControl(''),
    ESKI_ID          : new FormControl('')
  })

  requestData
  responseData

  grupFirmaTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async grupFirmaListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "grupFirmaTanimlari/grupFirmaListesi", {})
    if (this.responseData.DATA.length == 0) { this.grupFirmaTanimlari = null } else {this.grupFirmaTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async grupFirmaEkleButton() {
    this.grupFirmaTanimlariFormu.patchValue({
      islem                : 'grupFirmaTanimlari/grupFirmaEkle',
      method               : 'POST',
      e_grup_firma_adi     : ''
    })
    this.modalHeader.title = "Birim Ekleme Formu"
    this.modalAc(this.modalGrupFirmaTanimlari, 'md')
  }

  async grupFirmaDuzenleButton(secilenKayit) {
    this.grupFirmaTanimlariFormu.patchValue({
      islem                : 'grupFirmaTanimlari/grupFirmaDuzenle',
      method               : 'PUT',
      e_grup_firma_adi     : secilenKayit.e_birim_adi,
      ESKI_ID              : secilenKayit.e_id
    })
    this.modalHeader.title = "Birim Düzenleme Formu"
    this.modalAc(this.modalGrupFirmaTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.grupFirmaTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.grupFirmaTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.grupFirmaListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async grupFirmaSilButton(secilenKayit) {
    Swal.fire({
      title               : "Grup Firma Silinecek",
      text                : "Grup Firma Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.grupFirmaSil(secilenKayit)
      }
    })
  }

  async grupFirmaSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'grupFirmaTanimlari/grupFirmaSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.grupFirmaTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.grupFirmaTanimlari.splice(i, 1)
        if (this.grupFirmaTanimlari.length == 0) { this.grupFirmaTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}