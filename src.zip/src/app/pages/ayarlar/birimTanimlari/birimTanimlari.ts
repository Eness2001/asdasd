import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-birimTanimlari',
  templateUrl: './birimTanimlari.html'
})


export class birimTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalBirimTanimlari') modalBirimTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Birim Tanımları")
    this.bs.change(['Ayarlar', 'Birim Tanımları'])
    this.birimListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  birimTanimlariFormu = new FormGroup({
    islem           : new FormControl(''),
    method          : new FormControl(''),
    e_birim_adi     : new FormControl(''),
    ESKI_ID         : new FormControl('')
  })

  requestData
  responseData

  birimTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async birimListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "birimTanimlari/birimListesi", {})
    if (this.responseData.DATA.length == 0) { this.birimTanimlari = null } else {this.birimTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async birimEkleButton() {
    this.birimTanimlariFormu.patchValue({
      islem           : 'birimTanimlari/birimEkle',
      method          : 'POST',
      e_birim_adi     : ''
    })
    this.modalHeader.title = "Birim Ekleme Formu"
    this.modalAc(this.modalBirimTanimlari, 'md')
  }

  async birimDuzenleButton(secilenKayit) {
    this.birimTanimlariFormu.patchValue({
      islem           : 'birimTanimlari/birimDuzenle',
      method          : 'PUT',
      e_birim_adi     : secilenKayit.e_birim_adi,
      ESKI_ID         : secilenKayit.e_id
    })
    this.modalHeader.title = "Birim Düzenleme Formu"
    this.modalAc(this.modalBirimTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.birimTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.birimTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.birimListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async birimSilButton(secilenKayit) {
    Swal.fire({
      title               : "Birim Silinecek",
      text                : "Birim Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.birimSil(secilenKayit)
      }
    })
  }

  async birimSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'birimTanimlari/birimSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.birimTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.birimTanimlari.splice(i, 1)
        if (this.birimTanimlari.length == 0) { this.birimTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}