import { Component, OnInit, ViewChild, ElementRef } from '@angular/core'
import { webServisIslemCalistir } from '../../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { NgbModal, NgbModalConfig } from '@ng-bootstrap/ng-bootstrap'
import { FormGroup, FormControl } from '@angular/forms'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { BreadcrumpService } from 'src/app/core/services/breadcrump.service'

@Component({
  selector: 'app-teslimYeriTanimlari',
  templateUrl: './teslimYeriTanimlari.html'
})


export class teslimYeriTanimlariComponent implements OnInit {
  constructor(
    public islem : webServisIslemCalistir,
    private modalService: NgbModal,
    public modalConfig: NgbModalConfig,
    private toastr: ToastrService,
    private titleService: Title,
    private bs: BreadcrumpService,
  ) {
    modalConfig.backdrop = 'static'
    modalConfig.keyboard = false
    modalConfig.size = 'sm'
  }

  @ViewChild('modalTeslimYeriTanimlari') modalTeslimYeriTanimlari: ElementRef

  async ngOnInit() {
    this.titleService.setTitle("Platinum Marine | Teslim Yeri Tanımları")
    this.bs.change(['Ayarlar', 'Teslim Yeri Tanımları'])
    this.teslimYeriListele()
  }

  modalAc(content, size) {
    this.modalConfig.size = size
    this.modalService.open(content, { ariaLabelledBy: 'modal-basic-title', centered: true })
  }
  modalHeader = { title: '' }

  teslimYeriTanimlariFormu = new FormGroup({
    islem                : new FormControl(''),
    method               : new FormControl(''),
    e_sira               : new FormControl(''),
    e_teslim_yeri_tr     : new FormControl(''),
    e_teslim_yeri_en     : new FormControl(''),
    ESKI_ID              : new FormControl('')
  })

  requestData
  responseData

  teslimYeriTanimlari
  kayitSayisi

  mainLoader = false
  islemiKaydetBtn = false
  silinenKayitBtn = [false]

  async teslimYeriListele(): Promise<void> {
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("GET", "teslimYeriTanimlari/teslimYeriListesi", {})
    if (this.responseData.DATA.length == 0) { this.teslimYeriTanimlari = null } else {this.teslimYeriTanimlari = this.responseData.DATA}
    this.mainLoader = false
  }

  async teslimYeriEkleButton() {
    this.teslimYeriTanimlariFormu.patchValue({
      islem              : 'teslimYeriTanimlari/teslimYeriEkle',
      method             : 'POST',
      e_sira             : '',
      e_teslim_yeri_tr   : '',
      e_teslim_yeri_en   : '',
    })
    this.modalHeader.title = "Teslim Yeri Ekleme Formu"
    this.modalAc(this.modalTeslimYeriTanimlari, 'md')
  }

  async teslimYeriDuzenleButton(secilenKayit) {
    this.teslimYeriTanimlariFormu.patchValue({
      islem                : 'teslimYeriTanimlari/teslimYeriDuzenle',
      method               : 'PUT',
      e_sira               : secilenKayit.e_sira,
      e_teslim_yeri_tr     : secilenKayit.e_teslim_yeri_tr,
      e_teslim_yeri_en     : secilenKayit.e_teslim_yeri_en,
      ESKI_ID              : secilenKayit.e_id
    })
    this.modalHeader.title = "Teslim Yeri Düzenleme Formu"
    this.modalAc(this.modalTeslimYeriTanimlari, 'md')
  }

  async islemiKaydet(): Promise<void> {
    if (this.teslimYeriTanimlariFormu.valid) {
      this.islemiKaydetBtn = true

      this.requestData = Object.assign({}, this.teslimYeriTanimlariFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu(this.requestData.method, this.requestData.islem, this.requestData)

      if (this.responseData.S == "T") {
        this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
        this.teslimYeriListele()
        this.modalService.dismissAll()
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
      }

      this.islemiKaydetBtn = false
    }
  }

  async teslimYeriSilButton(secilenKayit) {
    Swal.fire({
      title               : "Teslim Yeri Silinecek",
      text                : "Teslim Yeri Sistemden Kalıcı Olarak Silinecek Emin Misiniz ?",
      icon                : 'warning',
      showCancelButton    : true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#6ca5d8',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.teslimYeriSil(secilenKayit)
      }
    })
  }

  async teslimYeriSil(secilenKayit): Promise<void> {
    this.silinenKayitBtn[secilenKayit.e_id] = true
    this.responseData = await this.islem.WebServisSorguSonucu("DELETE", 'teslimYeriTanimlari/teslimYeriSil', { ESKI_ID: secilenKayit.e_id })

    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      const i = this.teslimYeriTanimlari.indexOf(secilenKayit)
      if (i > -1) {
        this.teslimYeriTanimlari.splice(i, 1)
        if (this.teslimYeriTanimlari.length == 0) { this.teslimYeriTanimlari = null }
      }
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız", { timeOut: 3000, closeButton: true, progressBar: true })
    }
    this.silinenKayitBtn[secilenKayit.e_id] = false
  }

}


