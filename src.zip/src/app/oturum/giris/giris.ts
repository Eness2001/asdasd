import { Component, OnInit } from '@angular/core'
import { FormGroup, FormControl } from '@angular/forms'
import { AuthenticationService } from '../../core/services/auth.service'
import { webServisIslemCalistir, urlConfig } from '../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import { Title } from '@angular/platform-browser'
import { LocalStoreService } from "../../core/services/local-store.service"
import { LanguageService } from 'src/app/core/services/language.service'
import Swal from 'sweetalert2/dist/sweetalert2'

@Component({
  selector: 'app-giris',
  templateUrl: './giris.html'  
})

export class girisComponent implements OnInit {
  constructor(
    public authenticationService: AuthenticationService,
    private islem : webServisIslemCalistir,
    private toastr: ToastrService,
    private titleService: Title,
    private store: LocalStoreService,
    private translate : LanguageService
  ) { }

  ngOnInit() {
    Swal.close()
    this.translate.setLanguage('tr')
    this.admin_language = 'tr'

    this.urlConfig = urlConfig
    this.titleService.setTitle("Platinum Marine | Giriş")

    document.body.removeAttribute('data-layout')
    document.body.classList.add('auth-body-bg')

    this.girisFormu.reset()

		if (this.store.getItem("platinum_marine_kullanici_adi")) {
			this.girisFormu.patchValue({
				e_kullanici_adi   : this.store.getItem("platinum_marine_kullanici_adi"),
				e_beni_hatirla    : true,
			})
		} 

    document.getElementById('e_kullanici_adi').focus()
  }
  admin_language

  urlConfig
  requestData
  responseData

  girisFormu = new FormGroup ({
		e_kullanici_adi : new FormControl(''),
		e_sifre					: new FormControl(''),
		e_beni_hatirla	: new FormControl(true),
  })
  girisYapBtn = false

  async girisYap() {
    if (!this.girisFormu.invalid) {
      this.girisYapBtn = true
      this.requestData = Object.assign({}, this.girisFormu.value)
      this.responseData = await this.islem.WebServisSorguSonucu("POST", "authentication/login", this.requestData)
      if (this.responseData.BAGLANTI_HATASI) {
        this.girisYapBtn = false
        return null
      }

      await this.authenticationService.login(this.responseData)

      if (this.responseData.S == "T") {
        this.authenticationService.login(this.responseData)
        if (this.requestData.e_beni_hatirla) {
          this.store.setItem("platinum_marine_kullanici_adi", this.requestData.e_kullanici_adi)
        } else {
          this.store.setItem("platinum_marine_kullanici_adi", "")
        }

        window.location.href = './anasayfa'
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'Giriş Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
        this.authenticationService.logout()
        this.requestData.e_sifre = ""
      }

      this.girisYapBtn = false
    }
  }

  setAdminLanguage() {
    this.translate.setLanguage(this.admin_language)
  }
}