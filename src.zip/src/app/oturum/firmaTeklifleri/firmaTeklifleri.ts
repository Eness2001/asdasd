import { Component, OnInit } from '@angular/core'
import { FormGroup, FormControl } from '@angular/forms'
import { AuthenticationService } from '../../core/services/auth.service'
import { webServisIslemCalistir, urlConfig } from '../../ISLEM'
import { ToastrService } from 'ngx-toastr'
import Swal from 'sweetalert2/dist/sweetalert2'
import { Title } from '@angular/platform-browser'
import { ActivatedRoute } from "@angular/router";
import { formatDate } from '@angular/common'
import { HttpHeaders } from '@angular/common/http'
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-firmaTeklifleri',
  templateUrl: './firmaTeklifleri.html'  
})

export class firmaTeklifleriComponent implements OnInit {
  constructor(
    public authenticationService: AuthenticationService,
    private islem : webServisIslemCalistir,
    private toastr: ToastrService,
    private titleService: Title,
    private activatedRoute: ActivatedRoute,
    private hC : HttpClient,
  ) { }

  urlConfig
  async ngOnInit() {
    this.urlConfig = urlConfig
    this.titleService.setTitle("Platinum Marine | Teklif Ver")

    this.filterData.e_talep_uniq_id = this.activatedRoute.snapshot.params.ID
    this.talepDetayiListele()
  }

  loaderAc(MESAJ) {
    Swal.fire({
    html: '<span>' + MESAJ + '</span><br><div class="loader-bubble loader-bubble-primary mb-2"></div> ',
    showConfirmButton: false,
    allowOutsideClick: false
    })
  }

  talepKayitlariDetayFormu = new FormGroup({
    e_firma_unvani    : new FormControl(''),
    e_talep_numarasi  : new FormControl(''),
    e_tarih           : new FormControl(''),
  })

  responseData
  mainLoader = false

  talepDetaylari
  malzemeListesi

  topluTeslimTarihi
  topluDovizCinsi = ""

  filterData = {
    e_talep_uniq_id: "",
    ESKI_ID: "",
    e_firma_id: "",
    e_mid: '',
    e_logo_uzantisi: ''
  }
  
  async talepDetayiListele(){
    this.mainLoader = true
    this.responseData = await this.islem.WebServisSorguSonucu("POST", "tedarikIslemleri/tedarikciDosyaListele", this.filterData)
    if (this.responseData.DATA.length == 0) { this.talepDetaylari = null } else { 
      this.talepDetaylari = this.responseData.DATA[0]
      this.malzemeListesi = this.responseData.MALZEME_LISTESI
      this.talepKayitlariDetayFormu.patchValue({
        e_firma_unvani    : this.responseData.DATA[0].e_firma_unvani,
        e_talep_numarasi  : this.responseData.DATA[0].e_talep_numarasi  ,
        e_tarih           : formatDate(this.responseData.DATA[0].e_tarih, 'yyyy-MM-dd', 'en'),
      })
    }
    this.mainLoader = false
  }

  async talepDetayiDuzenle(secilenKayit){
    let requestData = secilenKayit

    requestData.ESKI_ID = secilenKayit.e_id
    requestData.e_fiyat = requestData.e_fiyat.toString().replace(",", ".")
    requestData.e_teslimat_zamani = requestData.e_teslimat_zamani.replace("T", " ")
    this.responseData = await this.islem.WebServisSorguSonucu("POST", "tedarikIslemleri/tedarikciFiyatGir", requestData)
    if (this.responseData.S == "T") {
      this.toastr.success(this.responseData.MESAJ, 'İşlem Başarılı !', { timeOut: 3000, closeButton: true, progressBar: true })
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
    }
  }

  async talepDetayiDuzenleDoviz(secilenKayit){
    for(const detay of this.talepDetaylari){
      detay.e_doviz_cinsi = secilenKayit.e_doviz_cinsi
      detay.ESKI_ID = detay.e_id
      this.responseData = await this.islem.WebServisSorguSonucu("PUT", "talepIslemleri/talepTeklifDetayiDuzenleFirma", detay)
      if (this.responseData.S == "T") {
     
      } else {
        this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
      }
    }
    this.toastr.success(this.responseData.MESAJ, 'İşlem Başarılı !', { timeOut: 3000, closeButton: true, progressBar: true })
  }


  //TOPLU TARİH GÜNCELLEME
  async topluTarihDuzenle(){
    this.responseData = await this.islem.WebServisSorguSonucu("POST", "tedarikIslemleri/tedarikciTopluTeslimatZamaniDuzenle", {e_teslimat_zamani: this.topluTeslimTarihi.replace('T', ' '), e_talep_uniq_id: this.filterData.e_talep_uniq_id})
    if (this.responseData.S == "T") {
      this.toastr.success(this.responseData.MESAJ, 'İşlem Başarılı !', { timeOut: 3000, closeButton: true, progressBar: true })
      this.talepDetayiListele()
      this.topluTeslimTarihi = ''
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
    }
  }


  /////////

  gonderBtn(){
    this.mailIcerik = document.getElementById("mailTable").innerHTML
    Swal.fire({
      title: 'Fiyatlar Gönderilecek!',
      text: "Girilen fiyatlar gönderilecek, İşlemi onaylıyor musunuz ?",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Evet, Gönder',
      confirmButtonColor: '#e38f14',
      cancelButtonText: 'İptal',
      cancelButtonColor: '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.loaderAc("Lütfen bekleyiniz, fiyatlar işleniyor...")
        this.gonder()
      }
    })
  }

  mailBilgileri
  mailIcerik
  async gonder(){
    this.responseData = await this.islem.WebServisSorguSonucu("POST", "firmaGenelAyarTanimlari/mailAyarlariListele2", {ID: this.filterData.e_talep_uniq_id})
    if (this.responseData.DATA.length == 0) { this.mailBilgileri = null } else { this.mailBilgileri = this.responseData.DATA[0]}

    let requestData = {
      islem                 : 'firmaGenelAyarTanimlari/mailGonderimListesineEkle2',
      method                : 'POST',
      ID                    : this.filterData.e_talep_uniq_id,
      e_islem_tipi          : 'Talep',
      e_gonderen_adi        : '"'+this.mailBilgileri.e_firma_unvani+'" <'+this.mailBilgileri.e_talep_mail_kullanici_adi+'>',
      // e_gonderilecek_adres  : this.talepKayitlariDetayFormu.value.e_mail_adresi,
      e_cc_adresi           : this.mailBilgileri.e_talep_mail_cc_adresi,
      // e_konu                : 'Gelen Fiyatlar Hakkinda - ' + this.talepKayitlariDetayFormu.value.e_talep_no,
      e_icerik              : this.mailIcerik,
      e_dosya_adresi        : ''
    }

    this.responseData = await this.islem.WebServisSorguSonucu(requestData.method, requestData.islem, requestData)
    if (this.responseData.S == "T") {
      this.toastr.success(this.responseData.MESAJ, 'İşlem Başarılı !', { timeOut: 3000, closeButton: true, progressBar: true })
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
    }

    this.responseData = await this.islem.WebServisSorguSonucu("PUT", "talepIslemleri/talepKayitlariFirmaKilitDurumuDegistir", {
      e_fiyat_verebilsin  : '0',
      ESKI_ID             : this.filterData.ESKI_ID
    })
    if (this.responseData.S == "T") {
      Swal.close()
      Swal.fire({
        title: 'İşlem Başarılı!',
        text: "Girilen fiyatlar başarıyla gönderildi.",
        icon: 'success',
        confirmButtonText: 'Tamam',
        confirmButtonColor: '#e38f14',
      })
      setTimeout(() => {
        location.reload()
      }, 2000);
    } else {
      Swal.close()
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
    }
  }

  nextInput(index){
    if (index + 1 < document.getElementsByClassName("fiyatInput").length){
      let input = document.getElementsByClassName("fiyatInput")[index + 1] as HTMLInputElement
      input.focus()
    } else {
      let input = document.getElementsByClassName("fiyatInput")[0] as HTMLInputElement
      input.focus()
    }
  }

  async topluDovizCinsiDuzenle(secilenKalemler){
    if (this.topluDovizCinsi) {
      this.loaderAc("Lütfen bekleyiniz, İşleminiz gerçekleştiriliyor...")
      for (let index = 0; index < secilenKalemler.length; index++) {
        secilenKalemler[index].e_doviz_cinsi = this.topluDovizCinsi
        secilenKalemler[index].ESKI_ID = secilenKalemler[index].e_id
        this.responseData = await this.islem.WebServisSorguSonucu("PUT", "talepIslemleri/talepTeklifDetayiDuzenleFirma", secilenKalemler[index])
        if (this.responseData.S == "T") {          
        } else {
          this.toastr.error(this.responseData.HATA_ACIKLAMASI, 'İşlem Başarısız !', { timeOut: 3000, closeButton: true, progressBar: true })
        }

        if (secilenKalemler.length == (index + 1)){
          location.reload()
        }
      }
      this.toastr.success(this.responseData.MESAJ, 'İşlem Başarılı !', { timeOut: 3000, closeButton: true, progressBar: true })
    }
  }

  dosyaYukleBtn(secilenKayit){
    this.secilenKalem = secilenKayit
    document.getElementById('eklenecekDosya').click()
  }

  secilenDosya
  islemiKaydetResimBtn
  requestData
  secilenKalem
  async dosyaKaydet(event: any) {
    this.secilenDosya = event.srcElement.files;
    this.islemiKaydetResimBtn = true
    if (this.secilenDosya) {
      this.requestData = {
        e_talep_detay_id  : this.secilenKalem.TALEP_DETAY_ID,
        e_dosya_uzantisi  : this.secilenDosya[0].name.split('.').pop(),
        e_dosya_adi       : this.talepKayitlariDetayFormu.value.e_firma_unvani  + ' / ' + this.secilenDosya[0].name.split('.')[0],
        e_tedarikci_id    : this.filterData.e_firma_id
      }
      this.responseData = await this.islem.WebServisSorguSonucu('POST', 'talepIslemleri/talepDetayDosyalarEkle', this.requestData)

      var formdata = new FormData();
      var file = new File([this.secilenDosya[0]], this.responseData.UNIQ_ID + "." + this.requestData.e_dosya_uzantisi);
      formdata.append("dosyalar", file)
      await this.dosyaYukle(formdata)
      this.talepDetayiListele()
    }
  }

  async dosyaYukle(formData): Promise<void> {
    var httpOptions = {
      headers: new HttpHeaders({
        "klasor" : "talepKalemDosyalari"
      })
    }

    await this.hC.post( urlConfig.PORT_URL + 'diger/dosyaYukle', formData, httpOptions).subscribe(
      data => async function() {
        this.toastr.success(this.responseData.MESAJ, await this.translate.get('genel.islem_basarili') + "", { timeOut: 3000, closeButton: true, progressBar: true })
      }, error => async function() {
        this.toastr.error(error, await this.translate.get('genel.islem_basarisiz') + "", { timeOut: 3000, closeButton: true, progressBar: true })
      }
    );
  }

  async dosyaSilButton(secilenKayit) {
    Swal.fire({
      title               : "Seçilen Dosya Silinecek!",
      text                : "Seçilen dosya sistemden kalıcı olarak silinecek emin misiniz?",
      icon                : 'warning',
      showCancelButton    :  true,
      confirmButtonText   : "Evet, Sil",
      confirmButtonColor  : '#e38f14',
      cancelButtonText    : "İptal",
      cancelButtonColor   : '#222'
    }).then((result) => {
      if (result.isConfirmed) {
        this.dosyaSil(secilenKayit)
      }
    })
  }

  async dosyaSil(secilenKayit): Promise<void> {
    this.responseData = await this.islem.WebServisSorguSonucu("POST", "talepIslemleri/talepDetayDosyalarSilTedarikci", { ESKI_ID: secilenKayit.e_id })
    if ((this.responseData.S) == "T") {
      this.toastr.success(this.responseData.MESAJ, "İşlem Başarılı!", { timeOut: 3000, closeButton: true, progressBar: true })
      this.talepDetayiListele()
    } else {
      this.toastr.error(this.responseData.HATA_ACIKLAMASI, "İşlem Başarısız!", { timeOut: 3000, closeButton: true, progressBar: true })
    }
  }

}