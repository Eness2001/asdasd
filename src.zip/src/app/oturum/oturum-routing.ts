import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { girisComponent } from './giris/giris';
import { firmaTeklifleriComponent } from './firmaTeklifleri/firmaTeklifleri';

const routes: Routes = [{
  path: 'giris', 
  component: girisComponent
},{
  path: 'firmaTeklifleri/:ID', 
  component: firmaTeklifleriComponent
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class oturumRoutingModule { }