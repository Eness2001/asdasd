import {
  MenuItem
} from './menu.model';

export const MENU: MenuItem[] = [{
  id: 1,
  label: 'Anasayfa',
  icon: 'ri-home-5-line',
  link: '/anasayfa'
}];
