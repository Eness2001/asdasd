import { MenuItem } from './menu.model';

export const MENU: MenuItem[] = [{
  label: 'Anasayfa',
  icon: 'ri-home-5-line',
  link: '/anasayfa'
},  {
	label: 'Tanım İşlemleri',
	isTitle: true
}, {
  label: 'Tanımlar',
  icon: 'ri-tools-fill',
  subItems: [{
    label: 'Kullanıcı Tanımları',
    link: '/ayarlar/kullaniciTanimlari'
  }, {
    label: 'Birim Tanımları',
    link: '/ayarlar/birimTanimlari'
  }, {
    label: 'Grup Tanımları',
    link: '/ayarlar/grupTanimlari'
  }, {
    label: 'Ödeme Tipi Tanımları',
    link: '/ayarlar/odemeTipiTanimlari'
  }, {
    label: 'Teslim Kosulu Tanımları',
    link: '/ayarlar/teslimKosuluTanimlari'
  }, {
    label: 'Teslim Yeri Tanımları',
    link: '/ayarlar/teslimYeriTanimlari'
  }, {
    label: 'Malzeme Tanimlari',
    link: '/ayarlar/malzemeTanimlari' 
  }, {
    label: 'Firma Tipi Tanımları',
    link: '/ayarlar/firmaTipiTanimlari'
  }, {
    label: 'Grup Firma Tanimlari',
    link: '/ayarlar/grupFirmaTanimlari'
  }, {
    label: 'Gemi Tipi Tanimlari',
    link: '/ayarlar/gemiTipiTanimlari'
  }, {
    label: 'Tedarikci Tanimlari',
    link: '/ayarlar/tedarikciTanimlari'
  }, {
    label: 'Gemi Listesi Tanimlari',
    link: '/ayarlar/gemiListesiTanimlari'
  }, {
    label: 'Musteri Tanimlari',
    link: '/ayarlar/musteriTanimlari'
  }
]}
]