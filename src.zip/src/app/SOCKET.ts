import { Injectable } from "@angular/core"
// import { io } from "socket.io-client";

@Injectable({
	providedIn: "root"
})

export class socketIslem {

	public socket : any;

	constructor() {}

	// socketBaglan(merkezKullaniciTipi){this.socket = io('https://test.eronsoftware.com:7210',{'forceNew':true, query: {"baglantiTipi": merkezKullaniciTipi}});}

	// socketAyril(){this.socket.disconnect()}
	// idSorgula() {this.socket.emit('idSorgula', '');}
	// yeniDosyaBilgisiGonder(data) {this.socket.emit('yeniDosyaBilgisiGonder', data);}
	// guncelDosyaBilgisiGonder(data) {this.socket.emit('guncelDosyaBilgisiGonder', data);}

	// onlineBildirimi() {this.socket.emit('login', {ID:JSON.parse(localStorage.getItem('PID')), PADI : JSON.parse(window.localStorage.getItem("fleet_kullanici_adi"))});}
	// mesajGonder(RPID,RPADI,HPID,MESAJ) {this.socket.emit('mesajGonder', {RPID:RPID, HPID:HPID,RPADI:RPADI, MESAJ:MESAJ});}
	// mesajGonder2(RPID,RPADI,HPID,MESAJ) {this.socket.emit('mesajGonder2', {RPID:RPID, HPID:HPID,RPADI:RPADI, MESAJ:MESAJ});}

	// yaziyorMesaji(RPID,RPADI,HPID) {this.socket.emit('yaziyor', {RPID:RPID, HPID:HPID,RPADI:RPADI});}
	// async onlineKullaniciListesiAl(){return new Promise<any[]>(resolve => {this.socket.emit('onlineKullaniciListesiTalep',{}, (kullaniciListesi) => {resolve(this.kullaniciListesiAyikla(kullaniciListesi));});});}

	// bildirimGonder(
	// 	DOSYA_ID,
	// 	DOSYA_ADI,
	// 	E_ID,
	// 	E_ISLEM_TIPI,
	// 	E_LOG,
	// 	E_TARIH,
	// 	E_PERSONEL_ID,
	// 	ERPID,
	// 	ERP_ADI,
	// 	ERPID_UNIQ_ID,
	// 	ERPID_UZANTI 
	// 	) {
	// 		this.socket.emit('bildirimGonder', 
	// 		{
	// 			DOSYA_ID : DOSYA_ID,
	// 			DOSYA_ADI: DOSYA_ADI,
	// 			E_ID : E_ID,
	// 			E_ISLEM_TIPI : E_ISLEM_TIPI,
	// 			E_LOG : E_LOG,
	// 			E_TARIH : E_TARIH,
	// 			E_PERSONEL_ID : E_PERSONEL_ID,
	// 			ERPID : ERPID,
	// 			ERP_ADI : ERP_ADI,
	// 			ERPID_UNIQ_ID : ERPID_UNIQ_ID,
	// 			ERPID_UZANTI : ERPID_UZANTI
	// 		}
	// 		)}
	
	// talepCevapVer(TALEP_ID,FIRMA_ID) {this.socket.emit('fiyatTalepCevap', {TALEP_ID : TALEP_ID,FIRMA_ID : FIRMA_ID})}
	// kullaniciListesiAyikla(jsonObj){var onlineKullaniciListesi = []; for (let index = 0; index < Object.keys(jsonObj).length; index++) {if (Object.keys(jsonObj)[index].length < 4){onlineKullaniciListesi.push(Object.keys(jsonObj)[index])}}; return onlineKullaniciListesi}
	
	// mesajToB2B(data) {this.socket.emit('mesajMerkezToB2B', data)}
} 