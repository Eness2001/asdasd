import { Injectable } from "@angular/core"

@Injectable ({
  providedIn: "root"
})

export class il_ilce_data {
  constructor( ) { }

  LISTE_IL = [
    {"e_il": "AFYON"},
    {"e_il": "ADANA"},
    {"e_il": "ADIYAMAN"},
    {"e_il": "AĞRI"},
    {"e_il": "AKSARAY"},
    {"e_il": "AMASYA"},
    {"e_il": "ANKARA"},
    {"e_il": "ANTALYA"},
    {"e_il": "ARDAHAN"},
    {"e_il": "ARTVİN"},
    {"e_il": "AYDIN"},
    {"e_il": "BALIKESİR"},
    {"e_il": "BARTIN"},
    {"e_il": "BATMAN"},
    {"e_il": "BAYBURT"},
    {"e_il": "BİLECİK"},
    {"e_il": "BİNGÖL"},
    {"e_il": "BİTLİS"},
    {"e_il": "BOLU"},
    {"e_il": "BURDUR"},
    {"e_il": "BURSA"},
    {"e_il": "ÇANAKKALE"},
    {"e_il": "ÇANKIRI"},
    {"e_il": "ÇORUM"},
    {"e_il": "DENİZLİ"},
    {"e_il": "DİYARBAKIR"},
    {"e_il": "DÜZCE"},
    {"e_il": "EDİRNE"},
    {"e_il": "ELAZIĞ"},
    {"e_il": "ERZİNCAN"},
    {"e_il": "ERZURUM"},
    {"e_il": "ESKİŞEHİR"},
    {"e_il": "GAZİANTEP"},
    {"e_il": "GİRESUN"},
    {"e_il": "GÜMÜŞHANE"},
    {"e_il": "HAKKARİ"},
    {"e_il": "HATAY"},
    {"e_il": "IĞDIR"},
    {"e_il": "ISPARTA"},
    {"e_il": "İSTANBUL"},
    {"e_il": "İZMİR"},
    {"e_il": "KAHRAMANMARAŞ"},
    {"e_il": "KARABÜK"},
    {"e_il": "KARAMAN"},
    {"e_il": "KARS"},
    {"e_il": "KASTAMONU"},
    {"e_il": "KAYSERİ"},
    {"e_il": "KIRIKKALE"},
    {"e_il": "KIRKLARELİ"},
    {"e_il": "KIRŞEHİR"},
    {"e_il": "KİLİS"},
    {"e_il": "KOCAELİ"},
    {"e_il": "KONYA"},
    {"e_il": "KÜTAHYA"},
    {"e_il": "MALATYA"},
    {"e_il": "MANİSA"},
    {"e_il": "MARDİN"},
    {"e_il": "MERSİN"},
    {"e_il": "MUĞLA"},
    {"e_il": "MUŞ"},
    {"e_il": "NEVŞEHİR"},
    {"e_il": "NİĞDE"},
    {"e_il": "ORDU"},
    {"e_il": "OSMANİYE"},
    {"e_il": "RİZE"},
    {"e_il": "SAKARYA"},
    {"e_il": "SAMSUN"},
    {"e_il": "SİİRT"},
    {"e_il": "SİNOP"},
    {"e_il": "SİVAS"},
    {"e_il": "ŞANLIURFA"},
    {"e_il": "ŞIRNAK"},
    {"e_il": "TEKİRDAĞ"},
    {"e_il": "TOKAT"},
    {"e_il": "TRABZON"},
    {"e_il": "TUNCELİ"},
    {"e_il": "UŞAK"},
    {"e_il": "VAN"},
    {"e_il": "YALOVA"},
    {"e_il": "YOZGAT"},
    {"e_il": "ZONGULDAK"}
  ]

  LISTE_ILCE = [
    {
      "e_il": "ADANA",
      "e_ilce": "Aladağ"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Ceyhan"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Çukurova"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Feke"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "İmamoğlu"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Karaisalı"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Karataş"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Kozan"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Pozantı"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Saimbeyli"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Sarıçam"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Seyhan"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Tufanbeyli"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Yumurtalık"
    },
    {
      "e_il": "ADANA",
      "e_ilce": "Yüreğir"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Besni"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Çelikhan"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Gerger"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Gölbaşı"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Kahta"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Samsat"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Sincik"
    },
    {
      "e_il": "ADIYAMAN",
      "e_ilce": "Tut"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Başmakçı"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Bayat"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Bolvadin"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Çay"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Çobanlar"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Dazkırı"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Dinar"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Emirdağ"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Evciler"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Hocalar"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "İhsaniye"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "İscehisar"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Kızılören"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Sandıklı"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Sinanpaşa"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Şuhut"
    },
    {
      "e_il": "AFYON",
      "e_ilce": "Sultandağı"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Ağaçören"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Eskil"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Gülağaç"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Güzelyurt"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Ortaköy"
    },
    {
      "e_il": "AKSARAY",
      "e_ilce": "Sarıyahşi"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Göynücek"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Gümüşhacıköy"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Hamamözü"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Merzifon"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Suluova"
    },
    {
      "e_il": "AMASYA",
      "e_ilce": "Taşova"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Akyurt"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Altındağ"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Ayaş"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Bala"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Beypazarı"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Çamlıdere"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Çankaya"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Çubuk"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Elmadağ"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Etimesgut"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Evren"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Gölbaşı"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Güdül"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Haymana"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Kalecik"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Kazan"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Keçiören"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Kızılcahamam"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Mamak"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Nallıhan"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Polatlı"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Pursaklar"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Şereflikoçhisar"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Sincan"
    },
    {
      "e_il": "ANKARA",
      "e_ilce": "Yenimahalle"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Akseki"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Aksu"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Alanya"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Demre"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Döşemealtı"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Elmalı"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Finike"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Gazipaşa"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "GündoğMUŞ"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "İbradı"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Kaş"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Kemer"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Kepez"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "KONYAaltı"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Korkuteli"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Kumluca"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Manavgat"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Muratpaşa"
    },
    {
      "e_il": "ANTALYA",
      "e_ilce": "Serik"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Çıldır"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Damal"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Göle"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Hanak"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ARDAHAN",
      "e_ilce": "Posof"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Ardanuç"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Arhavi"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Borçka"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Hopa"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Murgul"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Şavşat"
    },
    {
      "e_il": "ARTVİN",
      "e_ilce": "Yusufeli"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Bozdoğan"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Buharkent"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Çine"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Didim"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Efeler"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Germencik"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "İncirliova"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Karacasu"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Karpuzlu"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Koçarlı"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Köşk"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Kuşadası"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Kuyucak"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Nazilli"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Söke"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Sultanhisar"
    },
    {
      "e_il": "AYDIN",
      "e_ilce": "Yenipazar"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Diyadin"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Doğubayazıt"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Eleşkirt"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Hamur"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Patnos"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Taşlıçay"
    },
    {
      "e_il": "AĞRI",
      "e_ilce": "Tuta"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Altıeylül"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Ayvalık"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Balya"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Bandırma"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Bigadiç"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Burhaniye"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Dursunbey"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Edremit"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Erdek"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Gömeç"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Gönen"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Havran"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "İvrindi"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Karesi"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Kepsut"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Manyas"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Marmara"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Savaştepe"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Sındırgı"
    },
    {
      "e_il": "BALIKESİR",
      "e_ilce": "Susurluk"
    },
    {
      "e_il": "BARTIN",
      "e_ilce": "Amasra"
    },
    {
      "e_il": "BARTIN",
      "e_ilce": "Kurucaşile"
    },
    {
      "e_il": "BARTIN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BARTIN",
      "e_ilce": "Ulus"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Beşiri"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Gercüş"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Hasankeyf"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Kozluk"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BATMAN",
      "e_ilce": "Sason"
    },
    {
      "e_il": "BAYBURT",
      "e_ilce": "AYDINtepe"
    },
    {
      "e_il": "BAYBURT",
      "e_ilce": "Demirözü"
    },
    {
      "e_il": "BAYBURT",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "DörtdiVAN"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Gerede"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Göynük"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Kıbrıscık"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Mengen"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Mudurnu"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Seben"
    },
    {
      "e_il": "BOLU",
      "e_ilce": "Yeniçağa"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Ağlasun"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Altınyayla"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Bucak"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Çavdır"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Çeltikçi"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Gölhisar"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "KARAMANlı"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Kemer"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Tefenni"
    },
    {
      "e_il": "BURDUR",
      "e_ilce": "Yeşilova"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Büyükorhan"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Gemlik"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Gürsu"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Harmancık"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "İnegöl"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "İznik"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Karacabey"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Keles"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Kestel"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Mudanya"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Mustafakemalpaşa"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Nilüfer"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Orhaneli"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Orhangazi"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Osmangazi"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Yenişehir"
    },
    {
      "e_il": "BURSA",
      "e_ilce": "Yıldırım"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Bozüyük"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Gölpazarı"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "İnhisar"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Osmaneli"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Pazaryeri"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Söğüt"
    },
    {
      "e_il": "BİLECİK",
      "e_ilce": "Yenipazar"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Adaklı"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Genç"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Karlıova"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Kiğı"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Solhan"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Yayladere"
    },
    {
      "e_il": "BİNGÖL",
      "e_ilce": "Yedisu"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Adilcevaz"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Ahlat"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Güroymak"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Hizan"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "Mutki"
    },
    {
      "e_il": "BİTLİS",
      "e_ilce": "TatVAN"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Acıpayam"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Babadağ"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Baklan"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Bekilli"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Beyağaç"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Bozkurt"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Buldan"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Çal"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Çameli"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Çardak"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Çivril"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Güney"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Honaz"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Kale"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Merkezefendi"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Pamukkale"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Sarayköy"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Serinhisar"
    },
    {
      "e_il": "DENİZLİ",
      "e_ilce": "Tavas"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Akçakoca"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Çilimli"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Cumayeri"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Gölyaka"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Gümüşova"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Kaynaşlı"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "DÜZCE",
      "e_ilce": "Yığılca"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Bağlar"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Bismil"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Çermik"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Çınar"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Çüngüş"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Dicle"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Eğil"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Ergani"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Hani"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Hazro"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Kayapınar"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Kocaköy"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Kulp"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Lice"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "SilVAN"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Sur"
    },
    {
      "e_il": "DİYARBAKIR",
      "e_ilce": "Yenişehir"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Enez"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Havsa"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "İpsala"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Keşan"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Lalapaşa"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Meriç"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Süloğlu"
    },
    {
      "e_il": "EDİRNE",
      "e_ilce": "Uzunköprü"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Ağın"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Alacakaya"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Arıcak"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Baskil"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Karakoçan"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Keban"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "KoVANcılar"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Maden"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Palu"
    },
    {
      "e_il": "ELAZIĞ",
      "e_ilce": "Sivrice"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Aşkale"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Aziziye"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Çat"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Hınıs"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Horasan"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "İspir"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Karaçoban"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Karayazı"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Köprüköy"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Narman"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Oltu"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Olur"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Palandöken"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Pasinler"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Pazaryolu"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Şenkaya"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Tekman"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Tortum"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Uzundere"
    },
    {
      "e_il": "ERZURUM",
      "e_ilce": "Yakutiye"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Çayırlı"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "İliç"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Kemah"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Kemaliye"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Otlukbeli"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Refahiye"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Tercan"
    },
    {
      "e_il": "ERZİNCAN",
      "e_ilce": "Üzümlü"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Alpu"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Beylikova"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Çifteler"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Günyüzü"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Han"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "İnönü"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Mahmudiye"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Mihalgazi"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Mihalıççık"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Odunpazarı"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Sarıcakaya"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Seyitgazi"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Sivrihisar"
    },
    {
      "e_il": "ESKİŞEHİR",
      "e_ilce": "Tepebaşı"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Araban"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "İslahiye"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Karkamış"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Nizip"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Nurdağı"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Oğuzeli"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Şahinbey"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Şehitkamil"
    },
    {
      "e_il": "GAZİANTEP",
      "e_ilce": "Yavuzeli"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Kelkit"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Köse"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Kürtün"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Şiran"
    },
    {
      "e_il": "GÜMÜŞHANE",
      "e_ilce": "Torul"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Alucra"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Bulancak"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Çamoluk"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Çanakçı"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Dereli"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Doğankent"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Espiye"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Eynesil"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Görele"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Güce"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Keşap"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Piraziz"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Şebinkarahisar"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "TireBOLU"
    },
    {
      "e_il": "GİRESUN",
      "e_ilce": "Yağlıdere"
    },
    {
      "e_il": "HAKKARİ",
      "e_ilce": "Çukurca"
    },
    {
      "e_il": "HAKKARİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "HAKKARİ",
      "e_ilce": "Şemdinli"
    },
    {
      "e_il": "HAKKARİ",
      "e_ilce": "Yüksekova"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Altınözü"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Antakya"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Arsuz"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Belen"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Defne"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Dörtyol"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Erzin"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Hassa"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "İskenderun"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Kırıkhan"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Kumlu"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Payas"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Reyhanlı"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Samandağ"
    },
    {
      "e_il": "HATAY",
      "e_ilce": "Yayladağı"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Aksu"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Atabey"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Eğirdir"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Gelendost"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Gönen"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Keçiborlu"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Şarkikaraağaç"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Senirkent"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Sütçüler"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Uluborlu"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Yalvaç"
    },
    {
      "e_il": "ISPARTA",
      "e_ilce": "Yenişarbademli"
    },
    {
      "e_il": "IĞDIR",
      "e_ilce": "Aralık"
    },
    {
      "e_il": "IĞDIR",
      "e_ilce": "Karakoyunlu"
    },
    {
      "e_il": "IĞDIR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "IĞDIR",
      "e_ilce": "Tuzluca"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Afşin"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Andırın"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Çağlayancerit"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Dulkadiroğlu"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Ekinözü"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Elbistan"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Göksun"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Nurhak"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Onikişubat"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Pazarcık"
    },
    {
      "e_il": "KAHRAMANMARAŞ",
      "e_ilce": "Türkoğlu"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "Eflani"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "Eskipazar"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "Ovacık"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "SafranBOLU"
    },
    {
      "e_il": "KARABÜK",
      "e_ilce": "Yenice"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Ayrancı"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Başyayla"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Ermenek"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Kazımkarabekir"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KARAMAN",
      "e_ilce": "Sarıveliler"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Akyaka"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Arpaçay"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Digor"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Kağızman"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Sarıkamış"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Selim"
    },
    {
      "e_il": "KARS",
      "e_ilce": "Susuz"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Abana"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Ağlı"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Araç"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Azdavay"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Bozkurt"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Çatalzeytin"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Cide"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Daday"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Devrekani"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Doğanyurt"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Hanönü"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "İhsangazi"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "İneBOLU"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Küre"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Pınarbaşı"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Şenpazar"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Seydiler"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Taşköprü"
    },
    {
      "e_il": "KASTAMONU",
      "e_ilce": "Tosya"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Akkışla"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Bünyan"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Develi"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Felahiye"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Hacılar"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "İncesu"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Kocasinan"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Melikgazi"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Özvatan"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Pınarbaşı"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Sarıoğlan"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Sarız"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Talas"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Tomarza"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Yahyalı"
    },
    {
      "e_il": "KAYSERİ",
      "e_ilce": "Yeşilhisar"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Bahşili"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Balışeyh"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Çelebi"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Delice"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Karakeçili"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Keskin"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Sulakyurt"
    },
    {
      "e_il": "KIRIKKALE",
      "e_ilce": "Yahşihan"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Babaeski"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Demirköy"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Kofçaz"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Lüleburgaz"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "PehliVANköy"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Pınarhisar"
    },
    {
      "e_il": "KIRKLARELİ",
      "e_ilce": "Vize"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Akçakent"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Akpınar"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Boztepe"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Çiçekdağı"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Kaman"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KIRŞEHİR",
      "e_ilce": "Mucur"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Başiskele"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Çayırova"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Darıca"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Derince"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Dilovası"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Gebze"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Gölcük"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "İzmit"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Kandıra"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Karamürsel"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Kartepe"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Körfez"
    },
    {
      "e_il": "KOCAELİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Ahırlı"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Akören"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Akşehir"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Altınekin"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Beyşehir"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Bozkır"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Çeltik"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Cihanbeyli"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Çumra"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Derbent"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Derebucak"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Doğanhisar"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Emirgazi"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Ereğli"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Güneysınır"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Hadim"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Halkapınar"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Hüyük"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Ilgın"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Kadınhanı"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Karapınar"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Karatay"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Kulu"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Meram"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Sarayönü"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Selçuklu"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Seydişehir"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Taşkent"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Tuzlukçu"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Yalıhüyük"
    },
    {
      "e_il": "KONYA",
      "e_ilce": "Yunak"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Altıntaş"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Aslanapa"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Çavdarhisar"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Domaniç"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Dumlupınar"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Emet"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Gediz"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Hisarcık"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Pazarlar"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Şaphane"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Simav"
    },
    {
      "e_il": "KÜTAHYA",
      "e_ilce": "Tavşanlı"
    },
    {
      "e_il": "KİLİS",
      "e_ilce": "Elbeyli"
    },
    {
      "e_il": "KİLİS",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "KİLİS",
      "e_ilce": "Musabeyli"
    },
    {
      "e_il": "KİLİS",
      "e_ilce": "Polateli"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Akçadağ"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Arapgir"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "ArguVAN"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Battalgazi"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Darende"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Doğanşehir"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Doğanyol"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Hekimhan"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Kale"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Kuluncak"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Pütürge"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Yazıhan"
    },
    {
      "e_il": "MALATYA",
      "e_ilce": "Yeşilyurt"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Ahmetli"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Akhisar"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Alaşehir"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Demirci"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Gölmarmara"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Gördes"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Kırkağaç"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Köprübaşı"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Kula"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Salihli"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Sarıgöl"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Saruhanlı"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Şehzadeler"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Selendi"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Soma"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Turgutlu"
    },
    {
      "e_il": "MANİSA",
      "e_ilce": "Yunusemre"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Artuklu"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Dargeçit"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Derik"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Kızıltepe"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Mazıdağı"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Midyat"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Nusaybin"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Ömerli"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Savur"
    },
    {
      "e_il": "MARDİN",
      "e_ilce": "Yeşilli"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Akdeniz"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Anamur"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "AYDINcık"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Bozyazı"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Çamlıyayla"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Erdemli"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Gülnar"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Mezitli"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Mut"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Silifke"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Tarsus"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Toroslar"
    },
    {
      "e_il": "MERSİN",
      "e_ilce": "Yenişehir"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Bodrum"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Dalaman"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Datça"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Fethiye"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Kavaklıdere"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Köyceğiz"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Marmaris"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Menteşe"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Milas"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Ortaca"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Seydikemer"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Ula"
    },
    {
      "e_il": "MUĞLA",
      "e_ilce": "Yatağan"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Bulanık"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Hasköy"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Korkut"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Malazgirt"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "MUŞ",
      "e_ilce": "Varto"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Acıgöl"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "AVANos"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Derinkuyu"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Gülşehir"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Hacıbektaş"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Kozaklı"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "NEVŞEHİR",
      "e_ilce": "Ürgüp"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Altunhisar"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Bor"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Çamardı"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Çiftlik"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "NİĞDE",
      "e_ilce": "Ulukışla"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Akkuş"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Aybastı"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Çamaş"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Çatalpınar"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Çaybaşı"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Fatsa"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Gölköy"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Gülyalı"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Gürgentepe"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "İkizce"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Kabadüz"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Kabataş"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Korgan"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Kumru"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Mesudiye"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Perşembe"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Ulubey"
    },
    {
      "e_il": "ORDU",
      "e_ilce": "Ünye"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Bahçe"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Düziçi"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Hasanbeyli"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Kadirli"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Sumbas"
    },
    {
      "e_il": "OSMANİYE",
      "e_ilce": "Toprakkale"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Ardeşen"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Çamlıhemşin"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Çayeli"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Derepazarı"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Fındıklı"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Güneysu"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Hemşin"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "İkizdere"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "İyidere"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Kalkandere"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "RİZE",
      "e_ilce": "Pazar"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Adapazarı"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Akyazı"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Arifiye"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Erenler"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Ferizli"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Geyve"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Hendek"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Karapürçek"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Karasu"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Kaynarca"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Kocaali"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Pamukova"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Sapanca"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "SerdiVAN"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Söğütlü"
    },
    {
      "e_il": "SAKARYA",
      "e_ilce": "Taraklı"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Alaçam"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Asarcık"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Atakum"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Ayvacık"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Bafra"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Canik"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Çarşamba"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Havza"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "İlkadım"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Kavak"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Ladik"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Ondokuzmayıs"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Salıpazarı"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Tekkeköy"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Terme"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Vezirköprü"
    },
    {
      "e_il": "SAMSUN",
      "e_ilce": "Yakakent"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "AYDINlar"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "Baykan"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "Eruh"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "Kurtalan"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "Pervari"
    },
    {
      "e_il": "Siirt",
      "e_ilce": "ŞirVAN"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Ayancık"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Boyabat"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Dikmen"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Durağan"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Erfelek"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Gerze"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Saraydüzü"
    },
    {
      "e_il": "SİNOP",
      "e_ilce": "Türkeli"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Akıncılar"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Altınyayla"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Divriği"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Doğanşar"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Gemerek"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Gölova"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Gürün"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Hafik"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "İmranlı"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Kangal"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Koyulhisar"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Şarkışla"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Suşehri"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Ulaş"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Yıldızeli"
    },
    {
      "e_il": "SİVAS",
      "e_ilce": "Zara"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Çerkezköy"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Çorlu"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Ergene"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "HayraBOLU"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Kapaklı"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Malkara"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Marmaraereğlisi"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Muratlı"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Saray"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Şarköy"
    },
    {
      "e_il": "TEKİRDAĞ",
      "e_ilce": "Süleymanpaşa"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Almus"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Artova"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Başçiftlik"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Erbaa"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Niksar"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Pazar"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Reşadiye"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Sulusaray"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Turhal"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Yeşilyurt"
    },
    {
      "e_il": "TOKAT",
      "e_ilce": "Zile"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Akçaabat"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Araklı"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Arsin"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Beşikdüzü"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Çarşıbaşı"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Çaykara"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Dernekpazarı"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Düzköy"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Hayrat"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Köprübaşı"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Maçka"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Of"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Ortahisar"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Şalpazarı"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Sürmene"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Tonya"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Vakfıkebir"
    },
    {
      "e_il": "TRABZON",
      "e_ilce": "Yomra"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Çemişgezek"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Hozat"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Mazgirt"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Nazımiye"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Ovacık"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Pertek"
    },
    {
      "e_il": "TUNCELİ",
      "e_ilce": "Pülümür"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "Banaz"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "Eşme"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "Karahallı"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "SİVASlı"
    },
    {
      "e_il": "UŞAK",
      "e_ilce": "Ulubey"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Bahçesaray"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Başkale"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Çaldıran"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Çatak"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Edremit"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Erciş"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Gevaş"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Gürpınar"
    },
    {
      "e_il": "VAN",
      "e_ilce": "İpekyolu"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Muradiye"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Özalp"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Saray"
    },
    {
      "e_il": "VAN",
      "e_ilce": "Tuşba"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Altınova"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Armutlu"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Çiftlikköy"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Çınarcık"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "YALOVA",
      "e_ilce": "Termal"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Akdağmadeni"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "AYDINcık"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Boğazlıyan"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Çandır"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Çayıralan"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Çekerek"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Kadışehri"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Saraykent"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Sarıkaya"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Şefaatli"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Sorgun"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Yenifakılı"
    },
    {
      "e_il": "YOZGAT",
      "e_ilce": "Yerköy"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Alaplı"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Çaycuma"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Devrek"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Ereğli"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Gökçebey"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Kilimli"
    },
    {
      "e_il": "ZONGULDAK",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Ayvacık"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Bayramiç"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Biga"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Bozcaada"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Çan"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Eceabat"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Ezine"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "GeliBOLU"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "İmroz"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Lapseki"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ÇANAKKALE",
      "e_ilce": "Yenice"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Atkaracalar"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Bayramören"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Çerkeş"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "EldiVAN"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Ilgaz"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Kızılırmak"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Korgun"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Kurşunlu"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Orta"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Şabanözü"
    },
    {
      "e_il": "ÇANKIRI",
      "e_ilce": "Yapraklı"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Alaca"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Bayat"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Boğazkale"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Dodurga"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "İskilip"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Kargı"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Laçin"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Mecitözü"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Oğuzlar"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Ortaköy"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Osmancık"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Sungurlu"
    },
    {
      "e_il": "ÇORUM",
      "e_ilce": "Uğurludağ"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Adalar"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Arnavutköy"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Ataşehir"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Avcılar"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Bağcılar"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Bahçelievler"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Bakırköy"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Başakşehir"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Bayrampaşa"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Beşiktaş"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Beykoz"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Beylikdüzü"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Beyoğlu"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Büyükçekmece"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Çatalca"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Çekmeköy"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Esenler"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Esenyurt"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Eyüp"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Fatih"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Gaziosmanpaşa"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Güngören"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Kadıköy"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Kağıthane"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Kartal"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Küçükçekmece"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Maltepe"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Pendik"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Sancaktepe"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Sarıyer"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Şile"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Silivri"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Şişli"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Sultanbeyli"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Sultangazi"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Sultangazi"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Tuzla"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Ümraniye"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Üsküdar"
    },
    {
      "e_il": "İSTANBUL",
      "e_ilce": "Zeytinburnu"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Aliağa"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Balçova"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Bayındır"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Bayraklı"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Bergama"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Beydağ"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Bornova"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Buca"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Çeşme"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Çiğli"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Dikili"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Foça"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Gaziemir"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Güzelbahçe"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Karabağlar"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Karaburun"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Karşıyaka"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Kemalpaşa"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Kiraz"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Kınık"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Konak"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Menderes"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Menemen"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Narlıdere"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Ödemiş"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Seferihisar"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Selçuk"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Tire"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Torbalı"
    },
    {
      "e_il": "İZMİR",
      "e_ilce": "Urla"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Akçakale"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Birecik"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Bozova"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Ceylanpınar"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Eyyübiye"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Halfeti"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Haliliye"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Harran"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "HilVAN"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Karaköprü"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Siverek"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Suruç"
    },
    {
      "e_il": "ŞANLIURFA",
      "e_ilce": "Viranşehir"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Beytüşşebap"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Cizre"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Güçlükonak"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "İdil"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Merkez"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Silopi"
    },
    {
      "e_il": "ŞIRNAK",
      "e_ilce": "Uludere"
    }
  ]

  SECILEN_ILCELER = []

  ilGetir() {
    return this.LISTE_IL;
  }

  ilceGetir(IL) {
    this.SECILEN_ILCELER = []
    for (let i = 0; i < this.LISTE_ILCE.length; i++) {
      if (this.LISTE_ILCE[i].e_il == IL)
      {
        this.SECILEN_ILCELER.push({"e_ilce": this.LISTE_ILCE[i].e_ilce})
      }
    }
    return this.SECILEN_ILCELER
  }
}