import { Injectable } from "@angular/core"

@Injectable ({
  providedIn: "root"
})

export class ulke_data {
  constructor( ) { }

  LISTE_ULKE = [[{
    "id": "1",
    "iso": "AF",
    "name": "Afghanistan"
  },
  {
    "id": "2",
    "iso": "AL",
    "name": "Albania"
  },
  {
    "id": "3",
    "iso": "DZ",
    "name": "Algeria"
  },
  {
    "id": "4",
    "iso": "AS",
    "name": "American Samoa"
  },
  {
    "id": "5",
    "iso": "AD",
    "name": "Andorra"
  },
  {
    "id": "6",
    "iso": "AO",
    "name": "Angola"
  },
  {
    "id": "7",
    "iso": "AI",
    "name": "Anguilla"
  },
  {
    "id": "8",
    "iso": "AQ",
    "name": "Antarctica"
  },
  {
    "id": "9",
    "iso": "AG",
    "name": "Antigua and Barbuda"
  },
  {
    "id": "10",
    "iso": "AR",
    "name": "Argentina"
  },
  {
    "id": "11",
    "iso": "AM",
    "name": "Armenia"
  },
  {
    "id": "12",
    "iso": "AW",
    "name": "Aruba"
  },
  {
    "id": "13",
    "iso": "AU",
    "name": "Australia"
  },
  {
    "id": "14",
    "iso": "AT",
    "name": "Austria"
  },
  {
    "id": "15",
    "iso": "AZ",
    "name": "Azerbaijan"
  },
  {
    "id": "16",
    "iso": "BS",
    "name": "Bahamas"
  },
  {
    "id": "17",
    "iso": "BH",
    "name": "Bahrain"
  },
  {
    "id": "18",
    "iso": "BD",
    "name": "Bangladesh"
  },
  {
    "id": "19",
    "iso": "BB",
    "name": "Barbados"
  },
  {
    "id": "20",
    "iso": "BY",
    "name": "Belarus"
  },
  {
    "id": "21",
    "iso": "BE",
    "name": "Belgium"
  },
  {
    "id": "22",
    "iso": "BZ",
    "name": "Belize"
  },
  {
    "id": "23",
    "iso": "BJ",
    "name": "Benin"
  },
  {
    "id": "24",
    "iso": "BM",
    "name": "Bermuda"
  },
  {
    "id": "25",
    "iso": "BT",
    "name": "Bhutan"
  },
  {
    "id": "26",
    "iso": "BO",
    "name": "Bolivia"
  },
  {
    "id": "27",
    "iso": "BA",
    "name": "Bosnia and Herzegovina"
  },
  {
    "id": "28",
    "iso": "BW",
    "name": "Botswana"
  },
  {
    "id": "29",
    "iso": "BV",
    "name": "Bouvet Island"
  },
  {
    "id": "30",
    "iso": "BR",
    "name": "Brazil"
  },
  {
    "id": "31",
    "iso": "IO",
    "name": "British Indian Ocean Territory"
  },
  {
    "id": "32",
    "iso": "BN",
    "name": "Brunei Darussalam"
  },
  {
    "id": "33",
    "iso": "BG",
    "name": "Bulgaria"
  },
  {
    "id": "34",
    "iso": "BF",
    "name": "Burkina Faso"
  },
  {
    "id": "35",
    "iso": "BI",
    "name": "Burundi"
  },
  {
    "id": "36",
    "iso": "KH",
    "name": "Cambodia"
  },
  {
    "id": "37",
    "iso": "CM",
    "name": "Cameroon"
  },
  {
    "id": "38",
    "iso": "CA",
    "name": "Canada"
  },
  {
    "id": "39",
    "iso": "CV",
    "name": "Cape Verde"
  },
  {
    "id": "40",
    "iso": "KY",
    "name": "Cayman Islands"
  },
  {
    "id": "41",
    "iso": "CF",
    "name": "Central African Republic"
  },
  {
    "id": "42",
    "iso": "TD",
    "name": "Chad"
  },
  {
    "id": "43",
    "iso": "CL",
    "name": "Chile"
  },
  {
    "id": "44",
    "iso": "CN",
    "name": "China"
  },
  {
    "id": "45",
    "iso": "CX",
    "name": "Christmas Island"
  },
  {
    "id": "46",
    "iso": "CC",
    "name": "Cocos (Keeling) Islands"
  },
  {
    "id": "47",
    "iso": "CO",
    "name": "Colombia"
  },
  {
    "id": "48",
    "iso": "KM",
    "name": "Comoros"
  },
  {
    "id": "49",
    "iso": "CG",
    "name": "Congo"
  },
  {
    "id": "50",
    "iso": "CD",
    "name": "Congo, the Democratic Republic of the"
  },
  {
    "id": "51",
    "iso": "CK",
    "name": "Cook Islands"
  },
  {
    "id": "52",
    "iso": "CR",
    "name": "Costa Rica"
  },
  {
    "id": "53",
    "iso": "CI",
    "name": "Cote D'Ivoire"
  },
  {
    "id": "54",
    "iso": "HR",
    "name": "Croatia"
  },
  {
    "id": "55",
    "iso": "CU",
    "name": "Cuba"
  },
  {
    "id": "56",
    "iso": "CY",
    "name": "Cyprus"
  },
  {
    "id": "57",
    "iso": "CZ",
    "name": "Czech Republic"
  },
  {
    "id": "58",
    "iso": "DK",
    "name": "Denmark"
  },
  {
    "id": "59",
    "iso": "DJ",
    "name": "Djibouti"
  },
  {
    "id": "60",
    "iso": "DM",
    "name": "Dominica"
  },
  {
    "id": "61",
    "iso": "DO",
    "name": "Dominican Republic"
  },
  {
    "id": "62",
    "iso": "EC",
    "name": "Ecuador"
  },
  {
    "id": "63",
    "iso": "EG",
    "name": "Egypt"
  },
  {
    "id": "64",
    "iso": "SV",
    "name": "El Salvador"
  },
  {
    "id": "65",
    "iso": "GQ",
    "name": "Equatorial Guinea"
  },
  {
    "id": "66",
    "iso": "ER",
    "name": "Eritrea"
  },
  {
    "id": "67",
    "iso": "EE",
    "name": "Estonia"
  },
  {
    "id": "68",
    "iso": "ET",
    "name": "Ethiopia"
  },
  {
    "id": "69",
    "iso": "FK",
    "name": "Falkland Islands (Malvinas)"
  },
  {
    "id": "70",
    "iso": "FO",
    "name": "Faroe Islands"
  },
  {
    "id": "71",
    "iso": "FJ",
    "name": "Fiji"
  },
  {
    "id": "72",
    "iso": "FI",
    "name": "Finland"
  },
  {
    "id": "73",
    "iso": "FR",
    "name": "France"
  },
  {
    "id": "74",
    "iso": "GF",
    "name": "French Guiana"
  },
  {
    "id": "75",
    "iso": "PF",
    "name": "French Polynesia"
  },
  {
    "id": "76",
    "iso": "TF",
    "name": "French Southern Territories"
  },
  {
    "id": "77",
    "iso": "GA",
    "name": "Gabon"
  },
  {
    "id": "78",
    "iso": "GM",
    "name": "Gambia"
  },
  {
    "id": "79",
    "iso": "GE",
    "name": "Georgia"
  },
  {
    "id": "80",
    "iso": "DE",
    "name": "Germany"
  },
  {
    "id": "81",
    "iso": "GH",
    "name": "Ghana"
  },
  {
    "id": "82",
    "iso": "GI",
    "name": "Gibraltar"
  },
  {
    "id": "83",
    "iso": "GR",
    "name": "Greece"
  },
  {
    "id": "84",
    "iso": "GL",
    "name": "Greenland"
  },
  {
    "id": "85",
    "iso": "GD",
    "name": "Grenada"
  },
  {
    "id": "86",
    "iso": "GP",
    "name": "Guadeloupe"
  },
  {
    "id": "87",
    "iso": "GU",
    "name": "Guam"
  },
  {
    "id": "88",
    "iso": "GT",
    "name": "Guatemala"
  },
  {
    "id": "89",
    "iso": "GN",
    "name": "Guinea"
  },
  {
    "id": "90",
    "iso": "GW",
    "name": "Guinea-Bissau"
  },
  {
    "id": "91",
    "iso": "GY",
    "name": "Guyana"
  },
  {
    "id": "92",
    "iso": "HT",
    "name": "Haiti"
  },
  {
    "id": "93",
    "iso": "HM",
    "name": "Heard Island and Mcdonald Islands"
  },
  {
    "id": "94",
    "iso": "VA",
    "name": "Holy See (Vatican City State)"
  },
  {
    "id": "95",
    "iso": "HN",
    "name": "Honduras"
  },
  {
    "id": "96",
    "iso": "HK",
    "name": "Hong Kong"
  },
  {
    "id": "97",
    "iso": "HU",
    "name": "Hungary"
  },
  {
    "id": "98",
    "iso": "IS",
    "name": "Iceland"
  },
  {
    "id": "99",
    "iso": "IN",
    "name": "India"
  },
  {
    "id": "100",
    "iso": "ID",
    "name": "Indonesia"
  },
  {
    "id": "101",
    "iso": "IR",
    "name": "Iran, Islamic Republic of"
  },
  {
    "id": "102",
    "iso": "IQ",
    "name": "Iraq"
  },
  {
    "id": "103",
    "iso": "IE",
    "name": "Ireland"
  },
  {
    "id": "104",
    "iso": "IL",
    "name": "Israel"
  },
  {
    "id": "105",
    "iso": "IT",
    "name": "Italy"
  },
  {
    "id": "106",
    "iso": "JM",
    "name": "Jamaica"
  },
  {
    "id": "107",
    "iso": "JP",
    "name": "Japan"
  },
  {
    "id": "108",
    "iso": "JO",
    "name": "Jordan"
  },
  {
    "id": "109",
    "iso": "KZ",
    "name": "Kazakhstan"
  },
  {
    "id": "110",
    "iso": "KE",
    "name": "Kenya"
  },
  {
    "id": "111",
    "iso": "KI",
    "name": "Kiribati"
  },
  {
    "id": "112",
    "iso": "KP",
    "name": "Korea, Democratic People's Republic of"
  },
  {
    "id": "113",
    "iso": "KR",
    "name": "Korea, Republic of"
  },
  {
    "id": "114",
    "iso": "KW",
    "name": "Kuwait"
  },
  {
    "id": "115",
    "iso": "KG",
    "name": "Kyrgyzstan"
  },
  {
    "id": "116",
    "iso": "LA",
    "name": "Lao People's Democratic Republic"
  },
  {
    "id": "117",
    "iso": "LV",
    "name": "Latvia"
  },
  {
    "id": "118",
    "iso": "LB",
    "name": "Lebanon"
  },
  {
    "id": "119",
    "iso": "LS",
    "name": "Lesotho"
  },
  {
    "id": "120",
    "iso": "LR",
    "name": "Liberia"
  },
  {
    "id": "121",
    "iso": "LY",
    "name": "Libyan Arab Jamahiriya"
  },
  {
    "id": "122",
    "iso": "LI",
    "name": "Liechtenstein"
  },
  {
    "id": "123",
    "iso": "LT",
    "name": "Lithuania"
  },
  {
    "id": "124",
    "iso": "LU",
    "name": "Luxembourg"
  },
  {
    "id": "125",
    "iso": "MO",
    "name": "Macao"
  },
  {
    "id": "126",
    "iso": "MK",
    "name": "Macedonia, the Former Yugoslav Republic of"
  },
  {
    "id": "127",
    "iso": "MG",
    "name": "Madagascar"
  },
  {
    "id": "128",
    "iso": "MW",
    "name": "Malawi"
  },
  {
    "id": "129",
    "iso": "MY",
    "name": "Malaysia"
  },
  {
    "id": "130",
    "iso": "MV",
    "name": "Maldives"
  },
  {
    "id": "131",
    "iso": "ML",
    "name": "Mali"
  },
  {
    "id": "132",
    "iso": "MT",
    "name": "Malta"
  },
  {
    "id": "133",
    "iso": "MH",
    "name": "Marshall Islands"
  },
  {
    "id": "134",
    "iso": "MQ",
    "name": "Martinique"
  },
  {
    "id": "135",
    "iso": "MR",
    "name": "Mauritania"
  },
  {
    "id": "136",
    "iso": "MU",
    "name": "Mauritius"
  },
  {
    "id": "137",
    "iso": "YT",
    "name": "Mayotte"
  },
  {
    "id": "138",
    "iso": "MX",
    "name": "Mexico"
  },
  {
    "id": "139",
    "iso": "FM",
    "name": "Micronesia, Federated States of"
  },
  {
    "id": "140",
    "iso": "MD",
    "name": "Moldova, Republic of"
  },
  {
    "id": "141",
    "iso": "MC",
    "name": "Monaco"
  },
  {
    "id": "142",
    "iso": "MN",
    "name": "Mongolia"
  },
  {
    "id": "143",
    "iso": "MS",
    "name": "Montserrat"
  },
  {
    "id": "144",
    "iso": "MA",
    "name": "Morocco"
  },
  {
    "id": "145",
    "iso": "MZ",
    "name": "Mozambique"
  },
  {
    "id": "146",
    "iso": "MM",
    "name": "Myanmar"
  },
  {
    "id": "147",
    "iso": "NA",
    "name": "Namibia"
  },
  {
    "id": "148",
    "iso": "NR",
    "name": "Nauru"
  },
  {
    "id": "149",
    "iso": "NP",
    "name": "Nepal"
  },
  {
    "id": "150",
    "iso": "NL",
    "name": "Netherlands"
  },
  {
    "id": "151",
    "iso": "AN",
    "name": "Netherlands Antilles"
  },
  {
    "id": "152",
    "iso": "NC",
    "name": "New Caledonia"
  },
  {
    "id": "153",
    "iso": "NZ",
    "name": "New Zealand"
  },
  {
    "id": "154",
    "iso": "NI",
    "name": "Nicaragua"
  },
  {
    "id": "155",
    "iso": "NE",
    "name": "Niger"
  },
  {
    "id": "156",
    "iso": "NG",
    "name": "Nigeria"
  },
  {
    "id": "157",
    "iso": "NU",
    "name": "Niue"
  },
  {
    "id": "158",
    "iso": "NF",
    "name": "Norfolk Island"
  },
  {
    "id": "159",
    "iso": "MP",
    "name": "Northern Mariana Islands"
  },
  {
    "id": "160",
    "iso": "NO",
    "name": "Norway"
  },
  {
    "id": "161",
    "iso": "OM",
    "name": "Oman"
  },
  {
    "id": "162",
    "iso": "PK",
    "name": "Pakistan"
  },
  {
    "id": "163",
    "iso": "PW",
    "name": "Palau"
  },
  {
    "id": "164",
    "iso": "PS",
    "name": "Palestinian Territory, Occupied"
  },
  {
    "id": "165",
    "iso": "PA",
    "name": "Panama"
  },
  {
    "id": "166",
    "iso": "PG",
    "name": "Papua New Guinea"
  },
  {
    "id": "167",
    "iso": "PY",
    "name": "Paraguay"
  },
  {
    "id": "168",
    "iso": "PE",
    "name": "Peru"
  },
  {
    "id": "169",
    "iso": "PH",
    "name": "Philippines"
  },
  {
    "id": "170",
    "iso": "PN",
    "name": "Pitcairn"
  },
  {
    "id": "171",
    "iso": "PL",
    "name": "Poland"
  },
  {
    "id": "172",
    "iso": "PT",
    "name": "Portugal"
  },
  {
    "id": "173",
    "iso": "PR",
    "name": "Puerto Rico"
  },
  {
    "id": "174",
    "iso": "QA",
    "name": "Qatar"
  },
  {
    "id": "175",
    "iso": "RE",
    "name": "Reunion"
  },
  {
    "id": "176",
    "iso": "RO",
    "name": "Romania"
  },
  {
    "id": "177",
    "iso": "RU",
    "name": "Russian Federation"
  },
  {
    "id": "178",
    "iso": "RW",
    "name": "Rwanda"
  },
  {
    "id": "179",
    "iso": "SH",
    "name": "Saint Helena"
  },
  {
    "id": "180",
    "iso": "KN",
    "name": "Saint Kitts and Nevis"
  },
  {
    "id": "181",
    "iso": "LC",
    "name": "Saint Lucia"
  },
  {
    "id": "182",
    "iso": "PM",
    "name": "Saint Pierre and Miquelon"
  },
  {
    "id": "183",
    "iso": "VC",
    "name": "Saint Vincent and the Grenadines"
  },
  {
    "id": "184",
    "iso": "WS",
    "name": "Samoa"
  },
  {
    "id": "185",
    "iso": "SM",
    "name": "San Marino"
  },
  {
    "id": "186",
    "iso": "ST",
    "name": "Sao Tome and Principe"
  },
  {
    "id": "187",
    "iso": "SA",
    "name": "Saudi Arabia"
  },
  {
    "id": "188",
    "iso": "SN",
    "name": "Senegal"
  },
  {
    "id": "189",
    "iso": "CS",
    "name": "Serbia and Montenegro"
  },
  {
    "id": "190",
    "iso": "SC",
    "name": "Seychelles"
  },
  {
    "id": "191",
    "iso": "SL",
    "name": "Sierra Leone"
  },
  {
    "id": "192",
    "iso": "SG",
    "name": "Singapore"
  },
  {
    "id": "193",
    "iso": "SK",
    "name": "Slovakia"
  },
  {
    "id": "194",
    "iso": "SI",
    "name": "Slovenia"
  },
  {
    "id": "195",
    "iso": "SB",
    "name": "Solomon Islands"
  },
  {
    "id": "196",
    "iso": "SO",
    "name": "Somalia"
  },
  {
    "id": "197",
    "iso": "ZA",
    "name": "South Africa"
  },
  {
    "id": "198",
    "iso": "GS",
    "name": "South Georgia and the South Sandwich Islands"
  },
  {
    "id": "199",
    "iso": "ES",
    "name": "Spain"
  },
  {
    "id": "200",
    "iso": "LK",
    "name": "Sri Lanka"
  },
  {
    "id": "201",
    "iso": "SD",
    "name": "Sudan"
  },
  {
    "id": "202",
    "iso": "SR",
    "name": "Suriname"
  },
  {
    "id": "203",
    "iso": "SJ",
    "name": "Svalbard and Jan Mayen"
  },
  {
    "id": "204",
    "iso": "SZ",
    "name": "Swaziland"
  },
  {
    "id": "205",
    "iso": "SE",
    "name": "Sweden"
  },
  {
    "id": "206",
    "iso": "CH",
    "name": "Switzerland"
  },
  {
    "id": "207",
    "iso": "SY",
    "name": "Syrian Arab Republic"
  },
  {
    "id": "208",
    "iso": "TW",
    "name": "Taiwan, Province of China"
  },
  {
    "id": "209",
    "iso": "TJ",
    "name": "Tajikistan"
  },
  {
    "id": "210",
    "iso": "TZ",
    "name": "Tanzania, United Republic of"
  },
  {
    "id": "211",
    "iso": "TH",
    "name": "Thailand"
  },
  {
    "id": "212",
    "iso": "TL",
    "name": "Timor-Leste"
  },
  {
    "id": "213",
    "iso": "TG",
    "name": "Togo"
  },
  {
    "id": "214",
    "iso": "TK",
    "name": "Tokelau"
  },
  {
    "id": "215",
    "iso": "TO",
    "name": "Tonga"
  },
  {
    "id": "216",
    "iso": "TT",
    "name": "Trinidad and Tobago"
  },
  {
    "id": "217",
    "iso": "TN",
    "name": "Tunisia"
  },
  {
    "id": "218",
    "iso": "TR",
    "name": "Turkey"
  },
  {
    "id": "219",
    "iso": "TM",
    "name": "Turkmenistan"
  },
  {
    "id": "220",
    "iso": "TC",
    "name": "Turks and Caicos Islands"
  },
  {
    "id": "221",
    "iso": "TV",
    "name": "Tuvalu"
  },
  {
    "id": "222",
    "iso": "UG",
    "name": "Uganda"
  },
  {
    "id": "223",
    "iso": "UA",
    "name": "Ukraine"
  },
  {
    "id": "224",
    "iso": "AE",
    "name": "United Arab Emirates"
  },
  {
    "id": "225",
    "iso": "GB",
    "name": "United Kingdom"
  },
  {
    "id": "226",
    "iso": "US",
    "name": "United States"
  },
  {
    "id": "227",
    "iso": "UM",
    "name": "United States Minor Outlying Islands"
  },
  {
    "id": "228",
    "iso": "UY",
    "name": "Uruguay"
  },
  {
    "id": "229",
    "iso": "UZ",
    "name": "Uzbekistan"
  },
  {
    "id": "230",
    "iso": "VU",
    "name": "Vanuatu"
  },
  {
    "id": "231",
    "iso": "VE",
    "name": "Venezuela"
  },
  {
    "id": "232",
    "iso": "VN",
    "name": "Viet Nam"
  },
  {
    "id": "233",
    "iso": "VG",
    "name": "Virgin Islands, British"
  },
  {
    "id": "234",
    "iso": "VI",
    "name": "Virgin Islands, U.s."
  },
  {
    "id": "235",
    "iso": "WF",
    "name": "Wallis and Futuna"
  },
  {
    "id": "236",
    "iso": "EH",
    "name": "Western Sahara"
  },
  {
    "id": "237",
    "iso": "YE",
    "name": "Yemen"
  },
  {
    "id": "238",
    "iso": "ZM",
    "name": "Zambia"
  },
  {
    "id": "239",
    "iso": "ZW",
    "name": "Zimbabwe"
  },
  {
    "id": "240",
    "iso": "CW",
    "name": "Curacao"
  },
  {
    "id": "241",
    "iso": "IM",
    "name": "Isle of Man"
  }
]]

  ulkeGetir() {
    return this.LISTE_ULKE;
  }
}