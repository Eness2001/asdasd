// import { NgModule } from '@angular/core';
// import { CommonModule } from '@angular/common';
// import { FormDirective } from './form.directive';
// import { LastDirective } from './last-element.directive';

// const directives = [
//   FormDirective,
//   LastDirective
// ];

// @NgModule({
//   imports: [
//     CommonModule
//   ],
//   declarations: directives,
//   exports: directives
// })
// export class SharedFormDirectivesModule { }
