import { Injectable } from "@angular/core"
import { LocalStoreService } from "./local-store.service"
import { Router } from "@angular/router"
import { of } from "rxjs"
import { delay } from "rxjs/operators"

@Injectable({
  providedIn: "root"
})

export class AuthenticationService {
  authenticated = false
  
  constructor (
    private store: LocalStoreService,
    private router: Router
  ) {
    this.checkAuth()
  }

  checkAuth() {
    if (this.store.getItem("platinum_marine_token") == "") {
      this.authenticated = false
    } else {
      this.authenticated = true
    }
  }

  getuser() {
    return of ({})
  }

  login(credentials) {
    console.log(credentials);
    
    this.authenticated = true
    this.store.setItem("platinum_marine_token", credentials.UTOKEN)
    this.store.setItem("platinum_marine_personel_adi", credentials.e_personel_adi)
    this.store.setItem("platinum_marine_kullanici_id", credentials.PID)

    return of({}).pipe(delay(1500))
  }

  logout() {
    this.authenticated = false
    this.store.setItem("platinum_marine_token", "")
    this.store.setItem("platinum_marine_personel_adi", "")
    this.store.setItem("platinum_marine_kullanici_id", "")
    this.router.navigateByUrl("/giris")
  }
}